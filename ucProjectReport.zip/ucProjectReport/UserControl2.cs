﻿using System;
using Wisej.Web;

namespace UCProject
{
    public partial class UserControl2 : Wisej.Web.UserControl
    {
        public UserControl2()
        {
            InitializeComponent();
        }
    }
}
