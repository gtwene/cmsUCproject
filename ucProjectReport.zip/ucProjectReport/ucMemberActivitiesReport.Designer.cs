﻿namespace UCProject
{
    partial class ucMemberActivitiesReport
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new Wisej.Web.Panel();
            this.btnReportPreview = new Wisej.Web.Button();
            this.btnTitheList = new Wisej.Web.Button();
            this.panel3 = new Wisej.Web.Panel();
            this.panel5 = new Wisej.Web.Panel();
            this.linkLabelPeriodicMinistryActivity = new Wisej.Web.LinkLabel();
            this.linkLabelPeriodicMemberActivity = new Wisej.Web.LinkLabel();
            this.linkLabelRefreshReport = new Wisej.Web.LinkLabel();
            this.panel4 = new Wisej.Web.Panel();
            this.label2 = new Wisej.Web.Label();
            this.btnViewActivity = new Wisej.Web.Button();
            this.cbActivityType = new Wisej.Web.ComboBox();
            this.rbMembersActivity = new Wisej.Web.RadioButton();
            this.rbMinistryActivity = new Wisej.Web.RadioButton();
            this.panel7 = new Wisej.Web.Panel();
            this.panel6 = new Wisej.Web.Panel();
            this.label3 = new Wisej.Web.Label();
            this.dtpActivityTo = new Wisej.Web.DateTimePicker();
            this.label1 = new Wisej.Web.Label();
            this.dtpActivityFrom = new Wisej.Web.DateTimePicker();
            this.panel2 = new Wisej.Web.Panel();
            this.label4 = new Wisej.Web.Label();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel1.Controls.Add(this.btnReportPreview);
            this.panel1.Controls.Add(this.btnTitheList);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1070, 479);
            this.panel1.TabIndex = 0;
            this.panel1.TabStop = true;
            // 
            // btnReportPreview
            // 
            this.btnReportPreview.BackColor = System.Drawing.Color.Gainsboro;
            this.btnReportPreview.ForeColor = System.Drawing.Color.Black;
            this.btnReportPreview.Location = new System.Drawing.Point(107, 34);
            this.btnReportPreview.Name = "btnReportPreview";
            this.btnReportPreview.Size = new System.Drawing.Size(100, 27);
            this.btnReportPreview.TabIndex = 6;
            this.btnReportPreview.Text = "Report Preview";
            // 
            // btnTitheList
            // 
            this.btnTitheList.BackColor = System.Drawing.Color.Gainsboro;
            this.btnTitheList.ForeColor = System.Drawing.Color.Black;
            this.btnTitheList.Location = new System.Drawing.Point(4, 34);
            this.btnTitheList.Name = "btnTitheList";
            this.btnTitheList.Size = new System.Drawing.Size(100, 27);
            this.btnTitheList.TabIndex = 5;
            this.btnTitheList.Text = "Tither List";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Location = new System.Drawing.Point(3, 61);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1047, 440);
            this.panel3.TabIndex = 1;
            this.panel3.TabStop = true;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel5.Controls.Add(this.linkLabelPeriodicMinistryActivity);
            this.panel5.Controls.Add(this.linkLabelPeriodicMemberActivity);
            this.panel5.Controls.Add(this.linkLabelRefreshReport);
            this.panel5.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel5.HeaderForeColor = System.Drawing.Color.Black;
            this.panel5.Location = new System.Drawing.Point(533, 3);
            this.panel5.Name = "panel5";
            this.panel5.ShowCloseButton = false;
            this.panel5.ShowHeader = true;
            this.panel5.Size = new System.Drawing.Size(509, 432);
            this.panel5.TabIndex = 2;
            this.panel5.TabStop = true;
            this.panel5.Text = "Report Parameters";
            // 
            // linkLabelPeriodicMinistryActivity
            // 
            this.linkLabelPeriodicMinistryActivity.AutoSize = true;
            this.linkLabelPeriodicMinistryActivity.Location = new System.Drawing.Point(29, 61);
            this.linkLabelPeriodicMinistryActivity.Name = "linkLabelPeriodicMinistryActivity";
            this.linkLabelPeriodicMinistryActivity.Size = new System.Drawing.Size(144, 15);
            this.linkLabelPeriodicMinistryActivity.TabIndex = 5;
            this.linkLabelPeriodicMinistryActivity.Text = "Periodic Ministry Activity ";
            // 
            // linkLabelPeriodicMemberActivity
            // 
            this.linkLabelPeriodicMemberActivity.AutoSize = true;
            this.linkLabelPeriodicMemberActivity.Location = new System.Drawing.Point(29, 36);
            this.linkLabelPeriodicMemberActivity.Name = "linkLabelPeriodicMemberActivity";
            this.linkLabelPeriodicMemberActivity.Size = new System.Drawing.Size(147, 15);
            this.linkLabelPeriodicMemberActivity.TabIndex = 4;
            this.linkLabelPeriodicMemberActivity.Text = "Periodic Member Activity";
            // 
            // linkLabelRefreshReport
            // 
            this.linkLabelRefreshReport.Anchor = ((Wisej.Web.AnchorStyles)(((Wisej.Web.AnchorStyles.Top | Wisej.Web.AnchorStyles.Bottom) 
            | Wisej.Web.AnchorStyles.Left)));
            this.linkLabelRefreshReport.AutoSize = true;
            this.linkLabelRefreshReport.Location = new System.Drawing.Point(29, 15);
            this.linkLabelRefreshReport.Name = "linkLabelRefreshReport";
            this.linkLabelRefreshReport.Size = new System.Drawing.Size(92, 15);
            this.linkLabelRefreshReport.TabIndex = 3;
            this.linkLabelRefreshReport.Text = "Refresh Report";
            // 
            // panel4
            // 
            this.panel4.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel4.Controls.Add(this.label2);
            this.panel4.Controls.Add(this.btnViewActivity);
            this.panel4.Controls.Add(this.cbActivityType);
            this.panel4.Controls.Add(this.rbMembersActivity);
            this.panel4.Controls.Add(this.rbMinistryActivity);
            this.panel4.Controls.Add(this.panel7);
            this.panel4.Controls.Add(this.panel6);
            this.panel4.Location = new System.Drawing.Point(3, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(524, 432);
            this.panel4.TabIndex = 1;
            this.panel4.TabStop = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 120);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 15);
            this.label2.TabIndex = 7;
            this.label2.Text = "Activity Type :";
            // 
            // btnViewActivity
            // 
            this.btnViewActivity.Anchor = ((Wisej.Web.AnchorStyles)(((Wisej.Web.AnchorStyles.Top | Wisej.Web.AnchorStyles.Bottom) 
            | Wisej.Web.AnchorStyles.Left)));
            this.btnViewActivity.BackColor = System.Drawing.Color.Gainsboro;
            this.btnViewActivity.ForeColor = System.Drawing.Color.Black;
            this.btnViewActivity.ImageSource = "icon-search";
            this.btnViewActivity.Location = new System.Drawing.Point(308, 136);
            this.btnViewActivity.Name = "btnViewActivity";
            this.btnViewActivity.Size = new System.Drawing.Size(198, 27);
            this.btnViewActivity.TabIndex = 7;
            this.btnViewActivity.Text = "View Activities";
            // 
            // cbActivityType
            // 
            this.cbActivityType.Location = new System.Drawing.Point(21, 141);
            this.cbActivityType.Name = "cbActivityType";
            this.cbActivityType.Size = new System.Drawing.Size(229, 22);
            this.cbActivityType.TabIndex = 6;
            // 
            // rbMembersActivity
            // 
            this.rbMembersActivity.Location = new System.Drawing.Point(256, 87);
            this.rbMembersActivity.Name = "rbMembersActivity";
            this.rbMembersActivity.Size = new System.Drawing.Size(141, 22);
            this.rbMembersActivity.TabIndex = 5;
            this.rbMembersActivity.TabStop = true;
            this.rbMembersActivity.Text = "Members Activities";
            // 
            // rbMinistryActivity
            // 
            this.rbMinistryActivity.Location = new System.Drawing.Point(66, 87);
            this.rbMinistryActivity.Name = "rbMinistryActivity";
            this.rbMinistryActivity.Size = new System.Drawing.Size(131, 22);
            this.rbMinistryActivity.TabIndex = 4;
            this.rbMinistryActivity.TabStop = true;
            this.rbMinistryActivity.Text = "Ministry Activities";
            // 
            // panel7
            // 
            this.panel7.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel7.Location = new System.Drawing.Point(14, 184);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(492, 243);
            this.panel7.TabIndex = 3;
            this.panel7.TabStop = true;
            // 
            // panel6
            // 
            this.panel6.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel6.Controls.Add(this.label3);
            this.panel6.Controls.Add(this.dtpActivityTo);
            this.panel6.Controls.Add(this.label1);
            this.panel6.Controls.Add(this.dtpActivityFrom);
            this.panel6.Location = new System.Drawing.Point(14, 7);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(492, 71);
            this.panel6.TabIndex = 2;
            this.panel6.TabStop = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(241, 14);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(26, 15);
            this.label3.TabIndex = 5;
            this.label3.Text = "To :";
            // 
            // dtpActivityTo
            // 
            this.dtpActivityTo.Checked = false;
            this.dtpActivityTo.Location = new System.Drawing.Point(241, 35);
            this.dtpActivityTo.Name = "dtpActivityTo";
            this.dtpActivityTo.Size = new System.Drawing.Size(237, 22);
            this.dtpActivityTo.TabIndex = 6;
            this.dtpActivityTo.Value = new System.DateTime(2020, 11, 6, 9, 10, 4, 39);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Activity From :";
            // 
            // dtpActivityFrom
            // 
            this.dtpActivityFrom.Checked = false;
            this.dtpActivityFrom.Location = new System.Drawing.Point(6, 35);
            this.dtpActivityFrom.Name = "dtpActivityFrom";
            this.dtpActivityFrom.Size = new System.Drawing.Size(229, 22);
            this.dtpActivityFrom.TabIndex = 4;
            this.dtpActivityFrom.Value = new System.DateTime(2020, 11, 6, 9, 10, 4, 39);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightBlue;
            this.panel2.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel2.Controls.Add(this.label4);
            this.panel2.Dock = Wisej.Web.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1051, 33);
            this.panel2.TabIndex = 1;
            this.panel2.TabStop = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(21, 11);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(209, 15);
            this.label4.TabIndex = 7;
            this.label4.Text = "MEMBER ACTIVITIES - REPORTS";
            // 
            // ucMemberActivitiesReport
            // 
            this.Controls.Add(this.panel1);
            this.Name = "ucMemberActivitiesReport";
            this.Size = new System.Drawing.Size(1073, 545);
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.Panel panel1;
        private Wisej.Web.Panel panel3;
        private Wisej.Web.Panel panel5;
        private Wisej.Web.Panel panel4;
        private Wisej.Web.Label label2;
        private Wisej.Web.Button btnViewActivity;
        private Wisej.Web.ComboBox cbActivityType;
        private Wisej.Web.RadioButton rbMembersActivity;
        private Wisej.Web.RadioButton rbMinistryActivity;
        private Wisej.Web.Panel panel7;
        private Wisej.Web.Panel panel6;
        private Wisej.Web.Label label3;
        private Wisej.Web.DateTimePicker dtpActivityTo;
        private Wisej.Web.Label label1;
        private Wisej.Web.DateTimePicker dtpActivityFrom;
        private Wisej.Web.Panel panel2;
        private Wisej.Web.Label label4;
        private Wisej.Web.Button btnReportPreview;
        private Wisej.Web.Button btnTitheList;
        private Wisej.Web.LinkLabel linkLabelPeriodicMinistryActivity;
        private Wisej.Web.LinkLabel linkLabelPeriodicMemberActivity;
        private Wisej.Web.LinkLabel linkLabelRefreshReport;
    }
}
