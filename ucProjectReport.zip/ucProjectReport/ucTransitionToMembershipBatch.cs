﻿using System;
using Wisej.Web;

namespace UCProject
{
    public partial class ucTransitionToMembershipBatch : Wisej.Web.UserControl
    {
        public ucTransitionToMembershipBatch()
        {
            InitializeComponent();
        }

        private void panel1_PanelCollapsed(object sender, EventArgs e)
        {

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Controls.Clear();
        }

        private void btnAddMemberBatch_Click(object sender, EventArgs e)
        {
            try
            {
                if (Validate_Controls() == false)
                {
                    return;
                }

                DialogResult dialogResult = MessageBox.Show("Create Pre-member ?", GlobalValueCore.ApplicationName, MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {

                    if (CreatePreMember())
                    {

                        GlobalValueCore.InformationMessage("Pre member Created Successfully");
                        //CLEAR_TEXT();
                    }
                }
                else if (dialogResult == DialogResult.No)
                {
                    GlobalValueCore.InformationMessage("Cancelled by User");
                }
                //MessageBox.Show(""+branch.checkBranchName(txtBranchName.Text.ToString()));

            }
            catch (Exception ex)
            {
                GlobalValueCore.ExceptionMessage(ex.Message);
            }

        }



        private bool CreatePreMember()
        {
            throw new NotImplementedException();
        }

        private bool Validate_Controls()
        {

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtEnterPreMemberName.Text, "Please Enter Pre-Member Name. Process Aboretd !"))
            {
                txtEnterPreMemberName.Select();
                return false;
            }

            if(GlobalValueCore.CHECK_UI_IS_EMPTY(cbCreateSelectedPremember, cbCreateSelectedPremember.Text, ""))
            {
                cbCreateSelectedPremember.Select();
                return false;
            }

            return true;

        }
    }
}
