﻿namespace UCProject
{
    partial class ucUploadExistingMembers
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new Wisej.Web.Label();
            this.panel1 = new Wisej.Web.Panel();
            this.btnViewPending = new Wisej.Web.Button();
            this.panel3 = new Wisej.Web.Panel();
            this.panel2 = new Wisej.Web.Panel();
            this.label2 = new Wisej.Web.Label();
            this.txtSelectFile = new Wisej.Web.TextBox();
            this.btn = new Wisej.Web.Button();
            this.btnUploadData = new Wisej.Web.Button();
            this.btnAcademicRecordUpload = new Wisej.Web.Button();
            this.btnExcelFormat = new Wisej.Web.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("default, Arial Black", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(250, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(199, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Member Info Upload ";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel1.Controls.Add(this.btnViewPending);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(3, 58);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(710, 419);
            this.panel1.TabIndex = 1;
            this.panel1.TabStop = true;
            // 
            // btnViewPending
            // 
            this.btnViewPending.BackColor = System.Drawing.Color.Gainsboro;
            this.btnViewPending.ForeColor = System.Drawing.Color.Black;
            this.btnViewPending.Location = new System.Drawing.Point(463, 50);
            this.btnViewPending.Name = "btnViewPending";
            this.btnViewPending.Size = new System.Drawing.Size(177, 27);
            this.btnViewPending.TabIndex = 2;
            this.btnViewPending.Text = "View pending";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel3.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel3.HeaderForeColor = System.Drawing.Color.Black;
            this.panel3.Location = new System.Drawing.Point(3, 83);
            this.panel3.Name = "panel3";
            this.panel3.ShowCloseButton = false;
            this.panel3.ShowHeader = true;
            this.panel3.Size = new System.Drawing.Size(702, 331);
            this.panel3.TabIndex = 1;
            this.panel3.TabStop = true;
            this.panel3.Text = "Uploaded Tithers Data";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.txtSelectFile);
            this.panel2.Controls.Add(this.btn);
            this.panel2.Controls.Add(this.btnUploadData);
            this.panel2.Dock = Wisej.Web.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(708, 47);
            this.panel2.TabIndex = 0;
            this.panel2.TabStop = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(23, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "Select Excel File";
            // 
            // txtSelectFile
            // 
            this.txtSelectFile.LabelText = "";
            this.txtSelectFile.Location = new System.Drawing.Point(134, 8);
            this.txtSelectFile.Name = "txtSelectFile";
            this.txtSelectFile.Size = new System.Drawing.Size(235, 22);
            this.txtSelectFile.TabIndex = 2;
            // 
            // btn
            // 
            this.btn.BackColor = System.Drawing.Color.Gainsboro;
            this.btn.Font = new System.Drawing.Font("default", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.btn.ForeColor = System.Drawing.Color.Black;
            this.btn.Location = new System.Drawing.Point(387, 8);
            this.btn.Name = "btn";
            this.btn.Size = new System.Drawing.Size(46, 27);
            this.btn.TabIndex = 1;
            this.btn.Text = "...";
            // 
            // btnUploadData
            // 
            this.btnUploadData.BackColor = System.Drawing.Color.Gainsboro;
            this.btnUploadData.ForeColor = System.Drawing.Color.Black;
            this.btnUploadData.Location = new System.Drawing.Point(462, 8);
            this.btnUploadData.Name = "btnUploadData";
            this.btnUploadData.Size = new System.Drawing.Size(177, 27);
            this.btnUploadData.TabIndex = 0;
            this.btnUploadData.Text = "Upload Data";
            this.btnUploadData.Click += new System.EventHandler(this.btnUploadData_Click);
            // 
            // btnAcademicRecordUpload
            // 
            this.btnAcademicRecordUpload.BackColor = System.Drawing.Color.Gainsboro;
            this.btnAcademicRecordUpload.ForeColor = System.Drawing.Color.Black;
            this.btnAcademicRecordUpload.Location = new System.Drawing.Point(4, 32);
            this.btnAcademicRecordUpload.Name = "btnAcademicRecordUpload";
            this.btnAcademicRecordUpload.Size = new System.Drawing.Size(177, 27);
            this.btnAcademicRecordUpload.TabIndex = 4;
            this.btnAcademicRecordUpload.Text = "Academic Record Upload";
            // 
            // btnExcelFormat
            // 
            this.btnExcelFormat.BackColor = System.Drawing.Color.Gainsboro;
            this.btnExcelFormat.ForeColor = System.Drawing.Color.Black;
            this.btnExcelFormat.Location = new System.Drawing.Point(186, 32);
            this.btnExcelFormat.Name = "btnExcelFormat";
            this.btnExcelFormat.Size = new System.Drawing.Size(177, 27);
            this.btnExcelFormat.TabIndex = 5;
            this.btnExcelFormat.Text = "Excel Format";
            // 
            // ucUploadExistingMembers
            // 
            this.Controls.Add(this.btnAcademicRecordUpload);
            this.Controls.Add(this.btnExcelFormat);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Name = "ucUploadExistingMembers";
            this.Size = new System.Drawing.Size(716, 509);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.Label label1;
        private Wisej.Web.Panel panel1;
        private Wisej.Web.Button btnViewPending;
        private Wisej.Web.Panel panel3;
        private Wisej.Web.Panel panel2;
        private Wisej.Web.Label label2;
        private Wisej.Web.TextBox txtSelectFile;
        private Wisej.Web.Button btn;
        private Wisej.Web.Button btnUploadData;
        private Wisej.Web.Button btnAcademicRecordUpload;
        private Wisej.Web.Button btnExcelFormat;
    }
}
