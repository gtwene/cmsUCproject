﻿namespace UCProject
{
    partial class UCCreateFirstTimerOrNewConvertForm
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PCreateFirstTimer = new Wisej.Web.Panel();
            this.btnExistingMembers = new Wisej.Web.Button();
            this.btnCreateFirstTimerOrNewConvert = new Wisej.Web.Button();
            this.btnFirstTimeNewConvert = new Wisej.Web.Button();
            this.panel2 = new Wisej.Web.Panel();
            this.label1 = new Wisej.Web.Label();
            this.panel4 = new Wisej.Web.Panel();
            this.btnSearch = new Wisej.Web.Button();
            this.btnSaveAssignment = new Wisej.Web.Button();
            this.panel9 = new Wisej.Web.Panel();
            this.txtShepherdMinistry = new Wisej.Web.TextBox();
            this.toolBar1 = new Wisej.Web.ToolBar();
            this.btnAddShepherd = new Wisej.Web.ToolBarButton();
            this.btnCancel = new Wisej.Web.ToolBarButton();
            this.BtnClearAll = new Wisej.Web.ToolBarButton();
            this.txtShepherdMobileNo = new Wisej.Web.TextBox();
            this.label16 = new Wisej.Web.Label();
            this.txtShepherdDepartment = new Wisej.Web.TextBox();
            this.txtShepherdMemberNo = new Wisej.Web.TextBox();
            this.label15 = new Wisej.Web.Label();
            this.txtShepherdMemberType = new Wisej.Web.TextBox();
            this.label14 = new Wisej.Web.Label();
            this.txtShepherdFullName = new Wisej.Web.TextBox();
            this.label13 = new Wisej.Web.Label();
            this.label12 = new Wisej.Web.Label();
            this.label10 = new Wisej.Web.Label();
            this.panel8 = new Wisej.Web.Panel();
            this.txtMobileNo = new Wisej.Web.TextBox();
            this.txtFullName = new Wisej.Web.TextBox();
            this.txtMemberType = new Wisej.Web.TextBox();
            this.txtStatusDecision = new Wisej.Web.TextBox();
            this.txtServiceAttended = new Wisej.Web.TextBox();
            this.dtpDateOfAttendance = new Wisej.Web.DateTimePicker();
            this.txtPreMemberRefNo = new Wisej.Web.TextBox();
            this.toolBar2 = new Wisej.Web.ToolBar();
            this.btnAddPreMember = new Wisej.Web.ToolBarButton();
            this.btnCancelAddPremember = new Wisej.Web.ToolBarButton();
            this.btnClearAllAddPreMemner = new Wisej.Web.ToolBarButton();
            this.label11 = new Wisej.Web.Label();
            this.label9 = new Wisej.Web.Label();
            this.label8 = new Wisej.Web.Label();
            this.label7 = new Wisej.Web.Label();
            this.label6 = new Wisej.Web.Label();
            this.label4 = new Wisej.Web.Label();
            this.label3 = new Wisej.Web.Label();
            this.label2 = new Wisej.Web.Label();
            this.panel5 = new Wisej.Web.Panel();
            this.panel7 = new Wisej.Web.Panel();
            this.label21 = new Wisej.Web.Label();
            this.label22 = new Wisej.Web.Label();
            this.label23 = new Wisej.Web.Label();
            this.label24 = new Wisej.Web.Label();
            this.panel1 = new Wisej.Web.Panel();
            this.panel6 = new Wisej.Web.Panel();
            this.label20 = new Wisej.Web.Label();
            this.label19 = new Wisej.Web.Label();
            this.label18 = new Wisej.Web.Label();
            this.label17 = new Wisej.Web.Label();
            this.PCreateFirstTimer.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // PCreateFirstTimer
            // 
            this.PCreateFirstTimer.AutoScroll = true;
            this.PCreateFirstTimer.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.PCreateFirstTimer.Controls.Add(this.btnExistingMembers);
            this.PCreateFirstTimer.Controls.Add(this.btnCreateFirstTimerOrNewConvert);
            this.PCreateFirstTimer.Controls.Add(this.btnFirstTimeNewConvert);
            this.PCreateFirstTimer.Controls.Add(this.panel2);
            this.PCreateFirstTimer.Controls.Add(this.panel4);
            this.PCreateFirstTimer.Font = new System.Drawing.Font("@default", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.PCreateFirstTimer.Location = new System.Drawing.Point(10, 23);
            this.PCreateFirstTimer.Name = "PCreateFirstTimer";
            this.PCreateFirstTimer.Size = new System.Drawing.Size(913, 430);
            this.PCreateFirstTimer.TabIndex = 3;
            this.PCreateFirstTimer.TabStop = true;
            // 
            // btnExistingMembers
            // 
            this.btnExistingMembers.BackColor = System.Drawing.Color.Gainsboro;
            this.btnExistingMembers.ForeColor = System.Drawing.Color.Black;
            this.btnExistingMembers.Location = new System.Drawing.Point(403, 35);
            this.btnExistingMembers.Name = "btnExistingMembers";
            this.btnExistingMembers.Size = new System.Drawing.Size(200, 27);
            this.btnExistingMembers.TabIndex = 7;
            this.btnExistingMembers.Text = "Existing Members";
            // 
            // btnCreateFirstTimerOrNewConvert
            // 
            this.btnCreateFirstTimerOrNewConvert.BackColor = System.Drawing.Color.Gainsboro;
            this.btnCreateFirstTimerOrNewConvert.ForeColor = System.Drawing.Color.Black;
            this.btnCreateFirstTimerOrNewConvert.Location = new System.Drawing.Point(201, 35);
            this.btnCreateFirstTimerOrNewConvert.Name = "btnCreateFirstTimerOrNewConvert";
            this.btnCreateFirstTimerOrNewConvert.Size = new System.Drawing.Size(200, 27);
            this.btnCreateFirstTimerOrNewConvert.TabIndex = 6;
            this.btnCreateFirstTimerOrNewConvert.Text = "Create First Time Or New Convert";
            this.btnCreateFirstTimerOrNewConvert.Click += new System.EventHandler(this.btnCreateFirstTimerOrNewConvert_Click);
            // 
            // btnFirstTimeNewConvert
            // 
            this.btnFirstTimeNewConvert.BackColor = System.Drawing.Color.Gainsboro;
            this.btnFirstTimeNewConvert.ForeColor = System.Drawing.Color.Black;
            this.btnFirstTimeNewConvert.Location = new System.Drawing.Point(0, 35);
            this.btnFirstTimeNewConvert.Name = "btnFirstTimeNewConvert";
            this.btnFirstTimeNewConvert.Size = new System.Drawing.Size(200, 27);
            this.btnFirstTimeNewConvert.TabIndex = 5;
            this.btnFirstTimeNewConvert.Text = "First Time / New Convert Search";
            this.btnFirstTimeNewConvert.Click += new System.EventHandler(this.btnFirstTimeNewConvert_Click);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = Wisej.Web.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(894, 36);
            this.panel2.TabIndex = 2;
            this.panel2.TabStop = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("default, Arial Black", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(2, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(215, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "New Pre-member Data Entry";
            // 
            // panel4
            // 
            this.panel4.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel4.Controls.Add(this.btnSearch);
            this.panel4.Controls.Add(this.btnSaveAssignment);
            this.panel4.Controls.Add(this.panel9);
            this.panel4.Controls.Add(this.panel8);
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Controls.Add(this.panel1);
            this.panel4.Location = new System.Drawing.Point(1, 63);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(907, 600);
            this.panel4.TabIndex = 1;
            this.panel4.TabStop = true;
            this.panel4.Text = "Search Results";
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.Gainsboro;
            this.btnSearch.ForeColor = System.Drawing.Color.Black;
            this.btnSearch.ImageSource = "icon-search";
            this.btnSearch.Location = new System.Drawing.Point(691, 552);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(185, 38);
            this.btnSearch.TabIndex = 5;
            this.btnSearch.Text = "Search";
            // 
            // btnSaveAssignment
            // 
            this.btnSaveAssignment.BackColor = System.Drawing.Color.Gainsboro;
            this.btnSaveAssignment.ForeColor = System.Drawing.Color.Black;
            this.btnSaveAssignment.Location = new System.Drawing.Point(478, 552);
            this.btnSaveAssignment.Name = "btnSaveAssignment";
            this.btnSaveAssignment.Size = new System.Drawing.Size(185, 38);
            this.btnSaveAssignment.TabIndex = 4;
            this.btnSaveAssignment.Text = "Save Assignment";
            // 
            // panel9
            // 
            this.panel9.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel9.Controls.Add(this.txtShepherdMinistry);
            this.panel9.Controls.Add(this.toolBar1);
            this.panel9.Controls.Add(this.txtShepherdMobileNo);
            this.panel9.Controls.Add(this.label16);
            this.panel9.Controls.Add(this.txtShepherdDepartment);
            this.panel9.Controls.Add(this.txtShepherdMemberNo);
            this.panel9.Controls.Add(this.label15);
            this.panel9.Controls.Add(this.txtShepherdMemberType);
            this.panel9.Controls.Add(this.label14);
            this.panel9.Controls.Add(this.txtShepherdFullName);
            this.panel9.Controls.Add(this.label13);
            this.panel9.Controls.Add(this.label12);
            this.panel9.Controls.Add(this.label10);
            this.panel9.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel9.HeaderForeColor = System.Drawing.Color.Black;
            this.panel9.Location = new System.Drawing.Point(457, 252);
            this.panel9.Name = "panel9";
            this.panel9.ShowCloseButton = false;
            this.panel9.ShowHeader = true;
            this.panel9.Size = new System.Drawing.Size(445, 289);
            this.panel9.TabIndex = 1;
            this.panel9.TabStop = true;
            this.panel9.Text = "Shepherd Info.";
            // 
            // txtShepherdMinistry
            // 
            this.txtShepherdMinistry.LabelText = "";
            this.txtShepherdMinistry.Location = new System.Drawing.Point(141, 141);
            this.txtShepherdMinistry.Name = "txtShepherdMinistry";
            this.txtShepherdMinistry.Size = new System.Drawing.Size(233, 22);
            this.txtShepherdMinistry.TabIndex = 28;
            // 
            // toolBar1
            // 
            this.toolBar1.AutoSize = false;
            this.toolBar1.Buttons.AddRange(new Wisej.Web.ToolBarButton[] {
            this.btnAddShepherd,
            this.btnCancel,
            this.BtnClearAll});
            this.toolBar1.Dock = Wisej.Web.DockStyle.Bottom;
            this.toolBar1.Location = new System.Drawing.Point(0, 210);
            this.toolBar1.Name = "toolBar1";
            this.toolBar1.Size = new System.Drawing.Size(443, 49);
            this.toolBar1.TabIndex = 13;
            this.toolBar1.TabStop = false;
            // 
            // btnAddShepherd
            // 
            this.btnAddShepherd.ImageSource = "spinner-plus";
            this.btnAddShepherd.Name = "btnAddShepherd";
            this.btnAddShepherd.Text = "Add Shepherd";
            this.btnAddShepherd.Click += new System.EventHandler(this.btnAddShepherd_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.ImageSource = "icon-close";
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // BtnClearAll
            // 
            this.BtnClearAll.ImageSource = "tab-close";
            this.BtnClearAll.Name = "BtnClearAll";
            this.BtnClearAll.Text = "Clear All";
            this.BtnClearAll.Click += new System.EventHandler(this.BtnClearAll_Click);
            // 
            // txtShepherdMobileNo
            // 
            this.txtShepherdMobileNo.Location = new System.Drawing.Point(140, 113);
            this.txtShepherdMobileNo.Name = "txtShepherdMobileNo";
            this.txtShepherdMobileNo.Size = new System.Drawing.Size(233, 22);
            this.txtShepherdMobileNo.TabIndex = 27;
            // 
            // label16
            // 
            this.label16.Anchor = ((Wisej.Web.AnchorStyles)(((Wisej.Web.AnchorStyles.Top | Wisej.Web.AnchorStyles.Bottom) 
            | Wisej.Web.AnchorStyles.Left)));
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(44, 65);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(71, 15);
            this.label16.TabIndex = 12;
            this.label16.Text = "Member No";
            // 
            // txtShepherdDepartment
            // 
            this.txtShepherdDepartment.Location = new System.Drawing.Point(141, 86);
            this.txtShepherdDepartment.Name = "txtShepherdDepartment";
            this.txtShepherdDepartment.Size = new System.Drawing.Size(233, 22);
            this.txtShepherdDepartment.TabIndex = 26;
            // 
            // txtShepherdMemberNo
            // 
            this.txtShepherdMemberNo.Location = new System.Drawing.Point(141, 61);
            this.txtShepherdMemberNo.Name = "txtShepherdMemberNo";
            this.txtShepherdMemberNo.Size = new System.Drawing.Size(233, 22);
            this.txtShepherdMemberNo.TabIndex = 25;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(67, 144);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(48, 15);
            this.label15.TabIndex = 11;
            this.label15.Text = "Ministry";
            // 
            // txtShepherdMemberType
            // 
            this.txtShepherdMemberType.Location = new System.Drawing.Point(141, 35);
            this.txtShepherdMemberType.Name = "txtShepherdMemberType";
            this.txtShepherdMemberType.Size = new System.Drawing.Size(233, 22);
            this.txtShepherdMemberType.TabIndex = 24;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(44, 92);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(71, 15);
            this.label14.TabIndex = 10;
            this.label14.Text = "Department";
            // 
            // txtShepherdFullName
            // 
            this.txtShepherdFullName.LabelText = "";
            this.txtShepherdFullName.Location = new System.Drawing.Point(140, 7);
            this.txtShepherdFullName.Name = "txtShepherdFullName";
            this.txtShepherdFullName.Size = new System.Drawing.Size(234, 22);
            this.txtShepherdFullName.TabIndex = 23;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(31, 38);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(84, 15);
            this.label13.TabIndex = 9;
            this.label13.Text = "Member Type";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(53, 119);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(62, 15);
            this.label12.TabIndex = 9;
            this.label12.Text = "Mobile No";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(52, 8);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(63, 15);
            this.label10.TabIndex = 8;
            this.label10.Text = "Full Name";
            // 
            // panel8
            // 
            this.panel8.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel8.Controls.Add(this.txtMobileNo);
            this.panel8.Controls.Add(this.txtFullName);
            this.panel8.Controls.Add(this.txtMemberType);
            this.panel8.Controls.Add(this.txtStatusDecision);
            this.panel8.Controls.Add(this.txtServiceAttended);
            this.panel8.Controls.Add(this.dtpDateOfAttendance);
            this.panel8.Controls.Add(this.txtPreMemberRefNo);
            this.panel8.Controls.Add(this.toolBar2);
            this.panel8.Controls.Add(this.label11);
            this.panel8.Controls.Add(this.label9);
            this.panel8.Controls.Add(this.label8);
            this.panel8.Controls.Add(this.label7);
            this.panel8.Controls.Add(this.label6);
            this.panel8.Controls.Add(this.label4);
            this.panel8.Controls.Add(this.label3);
            this.panel8.Controls.Add(this.label2);
            this.panel8.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel8.HeaderForeColor = System.Drawing.Color.Black;
            this.panel8.Location = new System.Drawing.Point(3, 252);
            this.panel8.Name = "panel8";
            this.panel8.ShowCloseButton = false;
            this.panel8.ShowHeader = true;
            this.panel8.Size = new System.Drawing.Size(445, 343);
            this.panel8.TabIndex = 1;
            this.panel8.TabStop = true;
            this.panel8.Text = "Personal And Residence Info.";
            // 
            // txtMobileNo
            // 
            this.txtMobileNo.Location = new System.Drawing.Point(196, 168);
            this.txtMobileNo.Name = "txtMobileNo";
            this.txtMobileNo.Size = new System.Drawing.Size(233, 22);
            this.txtMobileNo.TabIndex = 22;
            // 
            // txtFullName
            // 
            this.txtFullName.Location = new System.Drawing.Point(195, 140);
            this.txtFullName.Name = "txtFullName";
            this.txtFullName.Size = new System.Drawing.Size(233, 22);
            this.txtFullName.TabIndex = 21;
            // 
            // txtMemberType
            // 
            this.txtMemberType.Location = new System.Drawing.Point(196, 113);
            this.txtMemberType.Name = "txtMemberType";
            this.txtMemberType.Size = new System.Drawing.Size(233, 22);
            this.txtMemberType.TabIndex = 20;
            // 
            // txtStatusDecision
            // 
            this.txtStatusDecision.Location = new System.Drawing.Point(196, 88);
            this.txtStatusDecision.Name = "txtStatusDecision";
            this.txtStatusDecision.Size = new System.Drawing.Size(233, 22);
            this.txtStatusDecision.TabIndex = 19;
            // 
            // txtServiceAttended
            // 
            this.txtServiceAttended.Location = new System.Drawing.Point(196, 62);
            this.txtServiceAttended.Name = "txtServiceAttended";
            this.txtServiceAttended.Size = new System.Drawing.Size(233, 22);
            this.txtServiceAttended.TabIndex = 18;
            // 
            // dtpDateOfAttendance
            // 
            this.dtpDateOfAttendance.Checked = false;
            this.dtpDateOfAttendance.Location = new System.Drawing.Point(196, 35);
            this.dtpDateOfAttendance.Name = "dtpDateOfAttendance";
            this.dtpDateOfAttendance.Size = new System.Drawing.Size(233, 22);
            this.dtpDateOfAttendance.TabIndex = 16;
            this.dtpDateOfAttendance.Value = new System.DateTime(2020, 10, 15, 6, 51, 56, 176);
            // 
            // txtPreMemberRefNo
            // 
            this.txtPreMemberRefNo.Location = new System.Drawing.Point(196, 7);
            this.txtPreMemberRefNo.Name = "txtPreMemberRefNo";
            this.txtPreMemberRefNo.Size = new System.Drawing.Size(233, 22);
            this.txtPreMemberRefNo.TabIndex = 15;
            // 
            // toolBar2
            // 
            this.toolBar2.AutoSize = false;
            this.toolBar2.Buttons.AddRange(new Wisej.Web.ToolBarButton[] {
            this.btnAddPreMember,
            this.btnCancelAddPremember,
            this.btnClearAllAddPreMemner});
            this.toolBar2.Dock = Wisej.Web.DockStyle.Bottom;
            this.toolBar2.Location = new System.Drawing.Point(0, 253);
            this.toolBar2.Name = "toolBar2";
            this.toolBar2.Size = new System.Drawing.Size(443, 60);
            this.toolBar2.TabIndex = 14;
            this.toolBar2.TabStop = false;
            // 
            // btnAddPreMember
            // 
            this.btnAddPreMember.ImageSource = "icon-new";
            this.btnAddPreMember.Name = "btnAddPreMember";
            this.btnAddPreMember.Text = "Add Pre Member";
            this.btnAddPreMember.Click += new System.EventHandler(this.btnAddPreMember_Click);
            // 
            // btnCancelAddPremember
            // 
            this.btnCancelAddPremember.ImageSource = "window-close";
            this.btnCancelAddPremember.Name = "btnCancelAddPremember";
            this.btnCancelAddPremember.Text = "Cancel";
            // 
            // btnClearAllAddPreMemner
            // 
            this.btnClearAllAddPreMemner.ImageSource = "messagebox-error";
            this.btnClearAllAddPreMemner.Name = "btnClearAllAddPreMemner";
            this.btnClearAllAddPreMemner.Text = "Clear All";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(532, 95);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(84, 15);
            this.label11.TabIndex = 8;
            this.label11.Text = "Member Type";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(105, 175);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(62, 15);
            this.label9.TabIndex = 7;
            this.label9.Text = "Mobile No";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(104, 147);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(63, 15);
            this.label8.TabIndex = 6;
            this.label8.Text = "Full Name";
            // 
            // label7
            // 
            this.label7.Anchor = ((Wisej.Web.AnchorStyles)(((Wisej.Web.AnchorStyles.Top | Wisej.Web.AnchorStyles.Bottom) 
            | Wisej.Web.AnchorStyles.Left)));
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(83, 121);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(84, 15);
            this.label7.TabIndex = 5;
            this.label7.Text = "Member Type";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(73, 87);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(94, 15);
            this.label6.TabIndex = 4;
            this.label6.Text = "Status Decision";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(64, 59);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 15);
            this.label4.TabIndex = 2;
            this.label4.Text = "Service Attended";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(49, 39);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(118, 15);
            this.label3.TabIndex = 1;
            this.label3.Text = "Date Of Attendance";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(47, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 15);
            this.label2.TabIndex = 0;
            this.label2.Text = "Pre-Member Ref No";
            // 
            // panel5
            // 
            this.panel5.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel5.Controls.Add(this.panel7);
            this.panel5.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel5.HeaderForeColor = System.Drawing.Color.Black;
            this.panel5.Location = new System.Drawing.Point(457, 4);
            this.panel5.Name = "panel5";
            this.panel5.ShowCloseButton = false;
            this.panel5.ShowHeader = true;
            this.panel5.Size = new System.Drawing.Size(445, 242);
            this.panel5.TabIndex = 3;
            this.panel5.TabStop = true;
            this.panel5.Text = "Shepherd (s)";
            // 
            // panel7
            // 
            this.panel7.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel7.Controls.Add(this.label21);
            this.panel7.Controls.Add(this.label22);
            this.panel7.Controls.Add(this.label23);
            this.panel7.Controls.Add(this.label24);
            this.panel7.Location = new System.Drawing.Point(3, 3);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(437, 206);
            this.panel7.TabIndex = 1;
            this.panel7.TabStop = true;
            // 
            // label21
            // 
            this.label21.Font = new System.Drawing.Font("default, Arial Black", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.label21.ForeColor = System.Drawing.Color.Black;
            this.label21.Location = new System.Drawing.Point(189, 3);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(114, 19);
            this.label21.TabIndex = 8;
            this.label21.Text = "Member Type";
            // 
            // label22
            // 
            this.label22.Font = new System.Drawing.Font("default, Arial Black", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.label22.ForeColor = System.Drawing.Color.Black;
            this.label22.Location = new System.Drawing.Point(318, 3);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(114, 19);
            this.label22.TabIndex = 7;
            this.label22.Text = "Department";
            // 
            // label23
            // 
            this.label23.Font = new System.Drawing.Font("default, Arial Black", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.label23.ForeColor = System.Drawing.Color.Black;
            this.label23.Location = new System.Drawing.Point(101, 3);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(114, 19);
            this.label23.TabIndex = 6;
            this.label23.Text = "Full Name";
            // 
            // label24
            // 
            this.label24.Font = new System.Drawing.Font("default, Arial Black", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.label24.ForeColor = System.Drawing.Color.Black;
            this.label24.Location = new System.Drawing.Point(3, 3);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(114, 19);
            this.label24.TabIndex = 5;
            this.label24.Text = "Reference No";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel1.Controls.Add(this.panel6);
            this.panel1.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel1.HeaderForeColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(3, 4);
            this.panel1.Name = "panel1";
            this.panel1.ShowCloseButton = false;
            this.panel1.ShowHeader = true;
            this.panel1.Size = new System.Drawing.Size(445, 242);
            this.panel1.TabIndex = 2;
            this.panel1.TabStop = true;
            this.panel1.Text = "Pre-Member";
            // 
            // panel6
            // 
            this.panel6.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel6.Controls.Add(this.label20);
            this.panel6.Controls.Add(this.label19);
            this.panel6.Controls.Add(this.label18);
            this.panel6.Controls.Add(this.label17);
            this.panel6.Location = new System.Drawing.Point(3, 3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(437, 206);
            this.panel6.TabIndex = 0;
            this.panel6.TabStop = true;
            // 
            // label20
            // 
            this.label20.Font = new System.Drawing.Font("default, Arial Black", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(287, 3);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(114, 19);
            this.label20.TabIndex = 4;
            this.label20.Text = "Member Type";
            // 
            // label19
            // 
            this.label19.Font = new System.Drawing.Font("default, Arial Black", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(191, 3);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(114, 19);
            this.label19.TabIndex = 3;
            this.label19.Text = "Mobile";
            // 
            // label18
            // 
            this.label18.Font = new System.Drawing.Font("default, Arial Black", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(101, 3);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(114, 19);
            this.label18.TabIndex = 2;
            this.label18.Text = "Full Name";
            // 
            // label17
            // 
            this.label17.Font = new System.Drawing.Font("default, Arial Black", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(3, 3);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(114, 19);
            this.label17.TabIndex = 1;
            this.label17.Text = "Reference No";
            // 
            // UCCreateFirstTimerOrNewConvertForm
            // 
            this.Controls.Add(this.PCreateFirstTimer);
            this.Name = "UCCreateFirstTimerOrNewConvertForm";
            this.Size = new System.Drawing.Size(926, 705);
            this.PCreateFirstTimer.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.Panel PCreateFirstTimer;
        private Wisej.Web.Panel panel4;
        private Wisej.Web.Panel panel2;
        private Wisej.Web.Label label1;
        private Wisej.Web.Button btnExistingMembers;
        private Wisej.Web.Button btnCreateFirstTimerOrNewConvert;
        private Wisej.Web.Button btnFirstTimeNewConvert;
        private Wisej.Web.Panel panel9;
        private Wisej.Web.ToolBar toolBar1;
        private Wisej.Web.Label label16;
        private Wisej.Web.Label label15;
        private Wisej.Web.Label label14;
        private Wisej.Web.Label label13;
        private Wisej.Web.Label label12;
        private Wisej.Web.Label label10;
        private Wisej.Web.Panel panel8;
        private Wisej.Web.ToolBar toolBar2;
        private Wisej.Web.Label label11;
        private Wisej.Web.Label label9;
        private Wisej.Web.Label label8;
        private Wisej.Web.Label label7;
        private Wisej.Web.Label label6;
        private Wisej.Web.Label label4;
        private Wisej.Web.Label label3;
        private Wisej.Web.Label label2;
        private Wisej.Web.Panel panel5;
        private Wisej.Web.Panel panel7;
        private Wisej.Web.Panel panel1;
        private Wisej.Web.Panel panel6;
        private Wisej.Web.TextBox txtShepherdMinistry;
        private Wisej.Web.TextBox txtShepherdMobileNo;
        private Wisej.Web.TextBox txtShepherdDepartment;
        private Wisej.Web.TextBox txtShepherdMemberNo;
        private Wisej.Web.TextBox txtShepherdMemberType;
        private Wisej.Web.TextBox txtShepherdFullName;
        private Wisej.Web.TextBox txtMobileNo;
        private Wisej.Web.TextBox txtFullName;
        private Wisej.Web.TextBox txtMemberType;
        private Wisej.Web.TextBox txtStatusDecision;
        private Wisej.Web.TextBox txtServiceAttended;
        private Wisej.Web.DateTimePicker dtpDateOfAttendance;
        private Wisej.Web.TextBox txtPreMemberRefNo;
        private Wisej.Web.Button btnSearch;
        private Wisej.Web.Button btnSaveAssignment;
        private Wisej.Web.ToolBarButton btnAddShepherd;
        private Wisej.Web.ToolBarButton btnCancel;
        private Wisej.Web.ToolBarButton BtnClearAll;
        private Wisej.Web.ToolBarButton btnAddPreMember;
        private Wisej.Web.ToolBarButton btnCancelAddPremember;
        private Wisej.Web.ToolBarButton btnClearAllAddPreMemner;
        private Wisej.Web.Label label21;
        private Wisej.Web.Label label22;
        private Wisej.Web.Label label23;
        private Wisej.Web.Label label24;
        private Wisej.Web.Label label20;
        private Wisej.Web.Label label19;
        private Wisej.Web.Label label18;
        private Wisej.Web.Label label17;
    }
}
