﻿using System;
using Wisej.Web;

namespace UCProject
{
    public partial class ucShepherdAssignment : Wisej.Web.UserControl
    {
        public ucShepherdAssignment()
        {
            InitializeComponent();
        }

        
        private void btnCreateFirstTimerOrNewConvert_Click(object sender, EventArgs e)
        {
          
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {

        }
    }
}
