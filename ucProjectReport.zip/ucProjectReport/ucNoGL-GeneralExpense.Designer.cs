﻿namespace UCProject
{
    partial class UserControl1
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new Wisej.Web.Panel();
            this.panel3 = new Wisej.Web.Panel();
            this.panel6 = new Wisej.Web.Panel();
            this.txtChequeNo2 = new Wisej.Web.TextBox();
            this.txtChequeNo = new Wisej.Web.TextBox();
            this.label10 = new Wisej.Web.Label();
            this.txtNarration = new Wisej.Web.TextBox();
            this.txtTransactionAmount = new Wisej.Web.TextBox();
            this.label8 = new Wisej.Web.Label();
            this.label9 = new Wisej.Web.Label();
            this.label7 = new Wisej.Web.Label();
            this.dtpActualDepositDate = new Wisej.Web.DateTimePicker();
            this.panel5 = new Wisej.Web.Panel();
            this.txtCashAccountCurrency = new Wisej.Web.TextBox();
            this.label5 = new Wisej.Web.Label();
            this.label4 = new Wisej.Web.Label();
            this.label6 = new Wisej.Web.Label();
            this.txtCashSmall = new Wisej.Web.TextBox();
            this.txtCashAccountNo = new Wisej.Web.TextBox();
            this.txtCashAccountTitle = new Wisej.Web.TextBox();
            this.panel4 = new Wisej.Web.Panel();
            this.txtDebitAccountCurrency = new Wisej.Web.TextBox();
            this.label2 = new Wisej.Web.Label();
            this.txtDebitSmall = new Wisej.Web.TextBox();
            this.txtBankAccountTitle = new Wisej.Web.TextBox();
            this.label1 = new Wisej.Web.Label();
            this.txtBankAccountNo = new Wisej.Web.TextBox();
            this.label3 = new Wisej.Web.Label();
            this.toolBar1 = new Wisej.Web.ToolBar();
            this.btnPostTrans = new Wisej.Web.ToolBarButton();
            this.btnCancelTrans = new Wisej.Web.ToolBarButton();
            this.btnViewAccount = new Wisej.Web.Button();
            this.rbNoGLBankAccount = new Wisej.Web.RadioButton();
            this.rbNoGLCashAccount = new Wisej.Web.RadioButton();
            this.panel2 = new Wisej.Web.Panel();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((Wisej.Web.AnchorStyles)(((Wisej.Web.AnchorStyles.Top | Wisej.Web.AnchorStyles.Left) 
            | Wisej.Web.AnchorStyles.Right)));
            this.panel1.AutoScroll = true;
            this.panel1.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.btnViewAccount);
            this.panel1.Controls.Add(this.rbNoGLBankAccount);
            this.panel1.Controls.Add(this.rbNoGLCashAccount);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(10, 40);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1109, 479);
            this.panel1.TabIndex = 0;
            this.panel1.TabStop = true;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel3.Controls.Add(this.panel6);
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.toolBar1);
            this.panel3.Location = new System.Drawing.Point(550, 1);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(530, 516);
            this.panel3.TabIndex = 9;
            this.panel3.TabStop = true;
            // 
            // panel6
            // 
            this.panel6.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel6.Controls.Add(this.txtChequeNo2);
            this.panel6.Controls.Add(this.txtChequeNo);
            this.panel6.Controls.Add(this.label10);
            this.panel6.Controls.Add(this.txtNarration);
            this.panel6.Controls.Add(this.txtTransactionAmount);
            this.panel6.Controls.Add(this.label8);
            this.panel6.Controls.Add(this.label9);
            this.panel6.Controls.Add(this.label7);
            this.panel6.Controls.Add(this.dtpActualDepositDate);
            this.panel6.Location = new System.Drawing.Point(3, 315);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(522, 159);
            this.panel6.TabIndex = 6;
            this.panel6.TabStop = true;
            // 
            // txtChequeNo2
            // 
            this.txtChequeNo2.Location = new System.Drawing.Point(218, 122);
            this.txtChequeNo2.Name = "txtChequeNo2";
            this.txtChequeNo2.Size = new System.Drawing.Size(215, 22);
            this.txtChequeNo2.TabIndex = 26;
            // 
            // txtChequeNo
            // 
            this.txtChequeNo.Location = new System.Drawing.Point(7, 122);
            this.txtChequeNo.Name = "txtChequeNo";
            this.txtChequeNo.Size = new System.Drawing.Size(202, 22);
            this.txtChequeNo.TabIndex = 24;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(7, 108);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(69, 15);
            this.label10.TabIndex = 25;
            this.label10.Text = "Cheque No";
            // 
            // txtNarration
            // 
            this.txtNarration.Location = new System.Drawing.Point(7, 61);
            this.txtNarration.Multiline = true;
            this.txtNarration.Name = "txtNarration";
            this.txtNarration.Size = new System.Drawing.Size(509, 41);
            this.txtNarration.TabIndex = 23;
            // 
            // txtTransactionAmount
            // 
            this.txtTransactionAmount.Location = new System.Drawing.Point(218, 21);
            this.txtTransactionAmount.Name = "txtTransactionAmount";
            this.txtTransactionAmount.Size = new System.Drawing.Size(298, 22);
            this.txtTransactionAmount.TabIndex = 19;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(218, 7);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(120, 15);
            this.label8.TabIndex = 21;
            this.label8.Text = "Transaction Amount";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(7, 46);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(57, 15);
            this.label9.TabIndex = 22;
            this.label9.Text = "Narration";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(7, 7);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(118, 15);
            this.label7.TabIndex = 20;
            this.label7.Text = "Actual Deposit Date";
            // 
            // dtpActualDepositDate
            // 
            this.dtpActualDepositDate.Checked = false;
            this.dtpActualDepositDate.Location = new System.Drawing.Point(6, 22);
            this.dtpActualDepositDate.Name = "dtpActualDepositDate";
            this.dtpActualDepositDate.Size = new System.Drawing.Size(203, 22);
            this.dtpActualDepositDate.TabIndex = 18;
            this.dtpActualDepositDate.Value = new System.DateTime(2020, 12, 15, 10, 40, 33, 952);
            // 
            // panel5
            // 
            this.panel5.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel5.Controls.Add(this.txtCashAccountCurrency);
            this.panel5.Controls.Add(this.label5);
            this.panel5.Controls.Add(this.label4);
            this.panel5.Controls.Add(this.label6);
            this.panel5.Controls.Add(this.txtCashSmall);
            this.panel5.Controls.Add(this.txtCashAccountNo);
            this.panel5.Controls.Add(this.txtCashAccountTitle);
            this.panel5.Location = new System.Drawing.Point(3, 158);
            this.panel5.Name = "panel5";
            this.panel5.ShowCloseButton = false;
            this.panel5.ShowHeader = true;
            this.panel5.Size = new System.Drawing.Size(522, 155);
            this.panel5.TabIndex = 6;
            this.panel5.TabStop = true;
            this.panel5.Text = "No GL Bank Account";
            // 
            // txtCashAccountCurrency
            // 
            this.txtCashAccountCurrency.Location = new System.Drawing.Point(83, 102);
            this.txtCashAccountCurrency.Name = "txtCashAccountCurrency";
            this.txtCashAccountCurrency.Size = new System.Drawing.Size(436, 22);
            this.txtCashAccountCurrency.TabIndex = 20;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(4, 2);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(113, 15);
            this.label5.TabIndex = 14;
            this.label5.Text = "Cash Account Title";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(4, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 15);
            this.label4.TabIndex = 17;
            this.label4.Text = "Cash Account No. ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(4, 83);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(141, 15);
            this.label6.TabIndex = 15;
            this.label6.Text = "Cash Account Currency";
            // 
            // txtCashSmall
            // 
            this.txtCashSmall.Location = new System.Drawing.Point(3, 102);
            this.txtCashSmall.Name = "txtCashSmall";
            this.txtCashSmall.Size = new System.Drawing.Size(74, 22);
            this.txtCashSmall.TabIndex = 19;
            // 
            // txtCashAccountNo
            // 
            this.txtCashAccountNo.Location = new System.Drawing.Point(3, 59);
            this.txtCashAccountNo.Name = "txtCashAccountNo";
            this.txtCashAccountNo.Size = new System.Drawing.Size(516, 22);
            this.txtCashAccountNo.TabIndex = 18;
            // 
            // txtCashAccountTitle
            // 
            this.txtCashAccountTitle.Location = new System.Drawing.Point(3, 17);
            this.txtCashAccountTitle.Name = "txtCashAccountTitle";
            this.txtCashAccountTitle.Size = new System.Drawing.Size(516, 22);
            this.txtCashAccountTitle.TabIndex = 16;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel4.Controls.Add(this.txtDebitAccountCurrency);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Controls.Add(this.txtDebitSmall);
            this.panel4.Controls.Add(this.txtBankAccountTitle);
            this.panel4.Controls.Add(this.label1);
            this.panel4.Controls.Add(this.txtBankAccountNo);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Location = new System.Drawing.Point(3, 3);
            this.panel4.Name = "panel4";
            this.panel4.ShowCloseButton = false;
            this.panel4.ShowHeader = true;
            this.panel4.Size = new System.Drawing.Size(522, 152);
            this.panel4.TabIndex = 5;
            this.panel4.TabStop = true;
            this.panel4.Text = "Expense Account";
            // 
            // txtDebitAccountCurrency
            // 
            this.txtDebitAccountCurrency.Location = new System.Drawing.Point(105, 99);
            this.txtDebitAccountCurrency.Name = "txtDebitAccountCurrency";
            this.txtDebitAccountCurrency.Size = new System.Drawing.Size(414, 22);
            this.txtDebitAccountCurrency.TabIndex = 13;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 15);
            this.label2.TabIndex = 10;
            this.label2.Text = "Bank Account No. ";
            // 
            // txtDebitSmall
            // 
            this.txtDebitSmall.Location = new System.Drawing.Point(2, 99);
            this.txtDebitSmall.Name = "txtDebitSmall";
            this.txtDebitSmall.Size = new System.Drawing.Size(97, 22);
            this.txtDebitSmall.TabIndex = 12;
            // 
            // txtBankAccountTitle
            // 
            this.txtBankAccountTitle.Location = new System.Drawing.Point(2, 18);
            this.txtBankAccountTitle.Name = "txtBankAccountTitle";
            this.txtBankAccountTitle.Size = new System.Drawing.Size(517, 22);
            this.txtBankAccountTitle.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 15);
            this.label1.TabIndex = 7;
            this.label1.Text = "Bank Account Title";
            // 
            // txtBankAccountNo
            // 
            this.txtBankAccountNo.Location = new System.Drawing.Point(2, 58);
            this.txtBankAccountNo.Name = "txtBankAccountNo";
            this.txtBankAccountNo.Size = new System.Drawing.Size(517, 22);
            this.txtBankAccountNo.TabIndex = 11;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 82);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(141, 15);
            this.label3.TabIndex = 8;
            this.label3.Text = "Debit Account Currency";
            // 
            // toolBar1
            // 
            this.toolBar1.AutoSize = false;
            this.toolBar1.Buttons.AddRange(new Wisej.Web.ToolBarButton[] {
            this.btnPostTrans,
            this.btnCancelTrans});
            this.toolBar1.Dock = Wisej.Web.DockStyle.None;
            this.toolBar1.Location = new System.Drawing.Point(3, 470);
            this.toolBar1.Name = "toolBar1";
            this.toolBar1.Size = new System.Drawing.Size(522, 45);
            this.toolBar1.TabIndex = 4;
            this.toolBar1.TabStop = false;
            // 
            // btnPostTrans
            // 
            this.btnPostTrans.ImageSource = "ajax-loader";
            this.btnPostTrans.Name = "btnPostTrans";
            this.btnPostTrans.Text = "Post Transaction";
            this.btnPostTrans.Click += new System.EventHandler(this.btnPostTrans_Click);
            // 
            // btnCancelTrans
            // 
            this.btnCancelTrans.ImageSource = "tab-close";
            this.btnCancelTrans.Name = "btnCancelTrans";
            this.btnCancelTrans.Text = "Cancel Transaction";
            this.btnCancelTrans.Click += new System.EventHandler(this.btnCancelTrans_Click);
            // 
            // btnViewAccount
            // 
            this.btnViewAccount.Location = new System.Drawing.Point(321, 1);
            this.btnViewAccount.Name = "btnViewAccount";
            this.btnViewAccount.Size = new System.Drawing.Size(134, 27);
            this.btnViewAccount.TabIndex = 8;
            this.btnViewAccount.Text = "View Accounts";
            // 
            // rbNoGLBankAccount
            // 
            this.rbNoGLBankAccount.Location = new System.Drawing.Point(3, 3);
            this.rbNoGLBankAccount.Name = "rbNoGLBankAccount";
            this.rbNoGLBankAccount.Size = new System.Drawing.Size(153, 22);
            this.rbNoGLBankAccount.TabIndex = 7;
            this.rbNoGLBankAccount.TabStop = true;
            this.rbNoGLBankAccount.Text = "No GL Bank Account";
            // 
            // rbNoGLCashAccount
            // 
            this.rbNoGLCashAccount.Location = new System.Drawing.Point(161, 3);
            this.rbNoGLCashAccount.Name = "rbNoGLCashAccount";
            this.rbNoGLCashAccount.Size = new System.Drawing.Size(154, 22);
            this.rbNoGLCashAccount.TabIndex = 6;
            this.rbNoGLCashAccount.TabStop = true;
            this.rbNoGLCashAccount.Text = "No GL Cash Account";
            // 
            // panel2
            // 
            this.panel2.Anchor = ((Wisej.Web.AnchorStyles)(((Wisej.Web.AnchorStyles.Top | Wisej.Web.AnchorStyles.Left) 
            | Wisej.Web.AnchorStyles.Right)));
            this.panel2.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel2.Location = new System.Drawing.Point(3, 38);
            this.panel2.Name = "panel2";
            this.panel2.ShowCloseButton = false;
            this.panel2.ShowHeader = true;
            this.panel2.Size = new System.Drawing.Size(502, 479);
            this.panel2.TabIndex = 5;
            this.panel2.TabStop = true;
            this.panel2.Text = "Bank Account";
            // 
            // UserControl1
            // 
            this.Controls.Add(this.panel1);
            this.Name = "UserControl1";
            this.Size = new System.Drawing.Size(1115, 522);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.Panel panel1;
        private Wisej.Web.Button btnViewAccount;
        private Wisej.Web.RadioButton rbNoGLBankAccount;
        private Wisej.Web.RadioButton rbNoGLCashAccount;
        private Wisej.Web.Panel panel2;
        private Wisej.Web.Panel panel3;
        private Wisej.Web.ToolBar toolBar1;
        private Wisej.Web.ToolBarButton btnPostTrans;
        private Wisej.Web.ToolBarButton btnCancelTrans;
        private Wisej.Web.Panel panel6;
        private Wisej.Web.Panel panel5;
        private Wisej.Web.Panel panel4;
        private Wisej.Web.TextBox txtDebitAccountCurrency;
        private Wisej.Web.Label label2;
        private Wisej.Web.TextBox txtDebitSmall;
        private Wisej.Web.TextBox txtBankAccountTitle;
        private Wisej.Web.Label label1;
        private Wisej.Web.TextBox txtBankAccountNo;
        private Wisej.Web.Label label3;
        private Wisej.Web.TextBox txtCashAccountCurrency;
        private Wisej.Web.Label label5;
        private Wisej.Web.Label label4;
        private Wisej.Web.Label label6;
        private Wisej.Web.TextBox txtCashSmall;
        private Wisej.Web.TextBox txtCashAccountNo;
        private Wisej.Web.TextBox txtCashAccountTitle;
        private Wisej.Web.TextBox txtChequeNo2;
        private Wisej.Web.TextBox txtChequeNo;
        private Wisej.Web.Label label10;
        private Wisej.Web.TextBox txtNarration;
        private Wisej.Web.TextBox txtTransactionAmount;
        private Wisej.Web.Label label8;
        private Wisej.Web.Label label9;
        private Wisej.Web.Label label7;
        private Wisej.Web.DateTimePicker dtpActualDepositDate;
    }
}
