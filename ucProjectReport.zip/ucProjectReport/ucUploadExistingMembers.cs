﻿using System;
using Wisej.Web;

namespace UCProject
{
    public partial class ucUploadExistingMembers : Wisej.Web.UserControl
    {
        public ucUploadExistingMembers()
        {
            InitializeComponent();
        }

        private void btnUploadData_Click(object sender, EventArgs e)
        {

        }
    }
}
