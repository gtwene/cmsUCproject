﻿using System;
using Wisej.Web;

namespace UCProject
{
    public partial class ucNoGLBankDeposit : Wisej.Web.UserControl
    {
        public ucNoGLBankDeposit()
        {
            InitializeComponent();
        }

        private void btnPostTrans_Click(object sender, EventArgs e)
        {
            try
            {
                if (Validate_Controls() == false)
                {
                    return;
                }

                DialogResult dialogResult = MessageBox.Show("Create Pre-member ?", GlobalValueCore.ApplicationName, MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {

                    if (CreatePreMember())
                    {

                        GlobalValueCore.InformationMessage("Pre member Created Successfully");
                        //CLEAR_TEXT();
                    }
                }
                else if (dialogResult == DialogResult.No)
                {
                    GlobalValueCore.InformationMessage("Cancelled by User");
                }
                //MessageBox.Show(""+branch.checkBranchName(txtBranchName.Text.ToString()));

            }
            catch (Exception ex)
            {
                GlobalValueCore.ExceptionMessage(ex.Message);
            }

        }

        private bool CreatePreMember()
        {
            throw new NotImplementedException();
        }

        private bool Validate_Controls()
        {

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtBankAccountTitle.Text, "Please Enter Bank Name !"))
            {
                txtBankAccountTitle.Select();
                return false;
            }



            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtBankAccountNo.Text, "Please Enter Account Number !"))
            {
                txtBankAccountNo.Select();
                return false;
            }


            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtDebitAccountCurrency.Text, "Debit Account. Process Aboretd !"))
            {
                txtDebitAccountCurrency.Select();
                return false;
            }


            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtCashAccountTitle.Text, "Cash Account."))
            {
                txtCashAccountTitle.Select();
                return false;
            }
            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtCashAccountNo.Text, "Enter Cash No.."))
            {
                txtCashAccountNo.Select();
                return false;
            }
            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtCashAccountCurrency.Text, "Cash Account Currency"))
            {
                txtCashAccountCurrency.Select();
                return false;

            }

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtTransactionAmount.Text, "Please Enter Transacction Amount"))
            {
                txtTransactionAmount.Select();
                return false;
            }

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtNarration.Text, "Please Enter Narration"))
            {
                txtNarration.Select();
                return false;
            }

            //if (cbEmploymentStatus.Text == "Student")
            //{
            //    pResidentialinfo.Show();

            //}else
            //{
            //    pStudentResidentialInfo_PanelCollapsed()
            //}


            return true;
        }

        private void btnCancelTrans_Click(object sender, EventArgs e)
        {
            CLEAR_TEXT();
        }
        private void CLEAR_TEXT()
        {
            txtBankAccountTitle.Text = txtBankAccountNo.Text = txtCashSmall.Text = txtDebitAccountCurrency.Text= txtNarration.Text = txtCashAccountCurrency.Text = txtCashAccountNo.Text = txtCashAccountTitle.Text = "";
           
        }
    }
  }

