﻿namespace UCProject
{
    partial class ucMembersInfoMembersReport
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new Wisej.Web.Panel();
            this.btnReportPreview = new Wisej.Web.Button();
            this.btnTitheList = new Wisej.Web.Button();
            this.panel3 = new Wisej.Web.Panel();
            this.panel5 = new Wisej.Web.Panel();
            this.panel9 = new Wisej.Web.Panel();
            this.label11 = new Wisej.Web.Label();
            this.dtpTo = new Wisej.Web.DateTimePicker();
            this.label8 = new Wisej.Web.Label();
            this.dtpFrom = new Wisej.Web.DateTimePicker();
            this.label9 = new Wisej.Web.Label();
            this.dateTimePicker5 = new Wisej.Web.DateTimePicker();
            this.comboBox13 = new Wisej.Web.ComboBox();
            this.cbPreMemberType = new Wisej.Web.ComboBox();
            this.panel8 = new Wisej.Web.Panel();
            this.txtAgeGroupTo = new Wisej.Web.TextBox();
            this.label10 = new Wisej.Web.Label();
            this.txtAgeGroupFrom = new Wisej.Web.TextBox();
            this.label6 = new Wisej.Web.Label();
            this.label7 = new Wisej.Web.Label();
            this.dateTimePicker4 = new Wisej.Web.DateTimePicker();
            this.comboBox10 = new Wisej.Web.ComboBox();
            this.cbGender = new Wisej.Web.ComboBox();
            this.txtGender = new Wisej.Web.TextBox();
            this.panel7 = new Wisej.Web.Panel();
            this.ckSurburb = new Wisej.Web.CheckBox();
            this.label5 = new Wisej.Web.Label();
            this.label4 = new Wisej.Web.Label();
            this.cbHomeCell = new Wisej.Web.ComboBox();
            this.txtHomeCell = new Wisej.Web.TextBox();
            this.dateTimePicker3 = new Wisej.Web.DateTimePicker();
            this.comboBox7 = new Wisej.Web.ComboBox();
            this.cbSurburb = new Wisej.Web.ComboBox();
            this.txtSurburb = new Wisej.Web.TextBox();
            this.panel6 = new Wisej.Web.Panel();
            this.label3 = new Wisej.Web.Label();
            this.cbDepartment = new Wisej.Web.ComboBox();
            this.txtDepartment = new Wisej.Web.TextBox();
            this.label2 = new Wisej.Web.Label();
            this.dateTimePicker2 = new Wisej.Web.DateTimePicker();
            this.comboBox3 = new Wisej.Web.ComboBox();
            this.cbMinistryChurch = new Wisej.Web.ComboBox();
            this.txtMinistryChurch = new Wisej.Web.TextBox();
            this.textBox1 = new Wisej.Web.TextBox();
            this.panel4 = new Wisej.Web.Panel();
            this.linkLabelPeriodicMemberDecision = new Wisej.Web.LinkLabel();
            this.linkLabelPeriodicAreaZone = new Wisej.Web.LinkLabel();
            this.linkLabelPeriodicMinistry = new Wisej.Web.LinkLabel();
            this.linkLabelPeriodicGlobal = new Wisej.Web.LinkLabel();
            this.label13 = new Wisej.Web.Label();
            this.linkLabelAgeGroup = new Wisej.Web.LinkLabel();
            this.linkLabelGenderSummaryEntireChurch = new Wisej.Web.LinkLabel();
            this.linkLabelGenderEntireChurch = new Wisej.Web.LinkLabel();
            this.linkLabelGenderAndMinistry = new Wisej.Web.LinkLabel();
            this.label12 = new Wisej.Web.Label();
            this.linkLabelMembershipDistribution = new Wisej.Web.LinkLabel();
            this.linkLabelEntireChurchSummaryGroupByDepartment = new Wisej.Web.LinkLabel();
            this.linkLabelEntireChurchSummaryGroupByMemberType = new Wisej.Web.LinkLabel();
            this.linkLabelEntireChurch = new Wisej.Web.LinkLabel();
            this.linkLabelHomeCell = new Wisej.Web.LinkLabel();
            this.linkLabelAreaZoneClass = new Wisej.Web.LinkLabel();
            this.linkLabelMinistryAndDepartment = new Wisej.Web.LinkLabel();
            this.linkLabelListByMinistry = new Wisej.Web.LinkLabel();
            this.linkLabelRefreshReport = new Wisej.Web.LinkLabel();
            this.panel2 = new Wisej.Web.Panel();
            this.label1 = new Wisej.Web.Label();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel1.Controls.Add(this.btnReportPreview);
            this.panel1.Controls.Add(this.btnTitheList);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(3, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1065, 451);
            this.panel1.TabIndex = 0;
            this.panel1.TabStop = true;
            // 
            // btnReportPreview
            // 
            this.btnReportPreview.BackColor = System.Drawing.Color.Gainsboro;
            this.btnReportPreview.ForeColor = System.Drawing.Color.Black;
            this.btnReportPreview.Location = new System.Drawing.Point(105, 40);
            this.btnReportPreview.Name = "btnReportPreview";
            this.btnReportPreview.Size = new System.Drawing.Size(100, 27);
            this.btnReportPreview.TabIndex = 4;
            this.btnReportPreview.Text = "Report Preview";
            // 
            // btnTitheList
            // 
            this.btnTitheList.BackColor = System.Drawing.Color.Gainsboro;
            this.btnTitheList.ForeColor = System.Drawing.Color.Black;
            this.btnTitheList.Location = new System.Drawing.Point(2, 40);
            this.btnTitheList.Name = "btnTitheList";
            this.btnTitheList.Size = new System.Drawing.Size(100, 27);
            this.btnTitheList.TabIndex = 3;
            this.btnTitheList.Text = "Tither List";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Location = new System.Drawing.Point(3, 68);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1043, 684);
            this.panel3.TabIndex = 2;
            this.panel3.TabStop = true;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel5.Controls.Add(this.panel9);
            this.panel5.Controls.Add(this.panel8);
            this.panel5.Controls.Add(this.panel7);
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Controls.Add(this.textBox1);
            this.panel5.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel5.HeaderForeColor = System.Drawing.Color.Black;
            this.panel5.Location = new System.Drawing.Point(3, 4);
            this.panel5.Name = "panel5";
            this.panel5.ShowCloseButton = false;
            this.panel5.ShowHeader = true;
            this.panel5.Size = new System.Drawing.Size(531, 676);
            this.panel5.TabIndex = 3;
            this.panel5.TabStop = true;
            this.panel5.Text = "Report Parameters";
            // 
            // panel9
            // 
            this.panel9.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel9.Controls.Add(this.label11);
            this.panel9.Controls.Add(this.dtpTo);
            this.panel9.Controls.Add(this.label8);
            this.panel9.Controls.Add(this.dtpFrom);
            this.panel9.Controls.Add(this.label9);
            this.panel9.Controls.Add(this.dateTimePicker5);
            this.panel9.Controls.Add(this.comboBox13);
            this.panel9.Controls.Add(this.cbPreMemberType);
            this.panel9.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel9.HeaderForeColor = System.Drawing.Color.Black;
            this.panel9.Location = new System.Drawing.Point(3, 450);
            this.panel9.Name = "panel9";
            this.panel9.ShowCloseButton = false;
            this.panel9.ShowHeader = true;
            this.panel9.Size = new System.Drawing.Size(523, 193);
            this.panel9.TabIndex = 10;
            this.panel9.TabStop = true;
            this.panel9.Text = "Pre-Member Reports Variables";
            // 
            // label11
            // 
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(3, 118);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(147, 14);
            this.label11.TabIndex = 11;
            this.label11.Text = "Pre-Member Type :";
            // 
            // dtpTo
            // 
            this.dtpTo.Checked = false;
            this.dtpTo.Location = new System.Drawing.Point(3, 83);
            this.dtpTo.Name = "dtpTo";
            this.dtpTo.Size = new System.Drawing.Size(291, 22);
            this.dtpTo.TabIndex = 10;
            this.dtpTo.Value = new System.DateTime(2020, 11, 6, 6, 6, 12, 116);
            // 
            // label8
            // 
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(3, 63);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(147, 14);
            this.label8.TabIndex = 9;
            this.label8.Text = "To :";
            // 
            // dtpFrom
            // 
            this.dtpFrom.Checked = false;
            this.dtpFrom.Location = new System.Drawing.Point(3, 26);
            this.dtpFrom.Name = "dtpFrom";
            this.dtpFrom.Size = new System.Drawing.Size(291, 22);
            this.dtpFrom.TabIndex = 3;
            this.dtpFrom.Value = new System.DateTime(2020, 11, 6, 6, 6, 12, 116);
            // 
            // label9
            // 
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(3, 6);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(208, 14);
            this.label9.TabIndex = 7;
            this.label9.Text = "From : ";
            // 
            // dateTimePicker5
            // 
            this.dateTimePicker5.Checked = false;
            this.dateTimePicker5.Location = new System.Drawing.Point(293, 297);
            this.dateTimePicker5.Name = "dateTimePicker5";
            this.dateTimePicker5.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker5.TabIndex = 3;
            this.dateTimePicker5.Value = new System.DateTime(2020, 11, 6, 6, 6, 12, 116);
            // 
            // comboBox13
            // 
            this.comboBox13.Location = new System.Drawing.Point(174, 245);
            this.comboBox13.Name = "comboBox13";
            this.comboBox13.Size = new System.Drawing.Size(120, 22);
            this.comboBox13.TabIndex = 2;
            // 
            // cbPreMemberType
            // 
            this.cbPreMemberType.Items.AddRange(new object[] {
            "First Timer",
            "Visitor",
            "Want To Be A Member"});
            this.cbPreMemberType.Location = new System.Drawing.Point(3, 138);
            this.cbPreMemberType.Name = "cbPreMemberType";
            this.cbPreMemberType.Size = new System.Drawing.Size(291, 22);
            this.cbPreMemberType.TabIndex = 1;
            // 
            // panel8
            // 
            this.panel8.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel8.Controls.Add(this.txtAgeGroupTo);
            this.panel8.Controls.Add(this.label10);
            this.panel8.Controls.Add(this.txtAgeGroupFrom);
            this.panel8.Controls.Add(this.label6);
            this.panel8.Controls.Add(this.label7);
            this.panel8.Controls.Add(this.dateTimePicker4);
            this.panel8.Controls.Add(this.comboBox10);
            this.panel8.Controls.Add(this.cbGender);
            this.panel8.Controls.Add(this.txtGender);
            this.panel8.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel8.HeaderForeColor = System.Drawing.Color.Black;
            this.panel8.Location = new System.Drawing.Point(3, 305);
            this.panel8.Name = "panel8";
            this.panel8.ShowCloseButton = false;
            this.panel8.ShowHeader = true;
            this.panel8.Size = new System.Drawing.Size(523, 138);
            this.panel8.TabIndex = 9;
            this.panel8.TabStop = true;
            this.panel8.Text = "Age Group & Gender Class";
            // 
            // txtAgeGroupTo
            // 
            this.txtAgeGroupTo.Location = new System.Drawing.Point(263, 83);
            this.txtAgeGroupTo.Name = "txtAgeGroupTo";
            this.txtAgeGroupTo.Size = new System.Drawing.Size(256, 22);
            this.txtAgeGroupTo.TabIndex = 11;
            // 
            // label10
            // 
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(263, 63);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(208, 14);
            this.label10.TabIndex = 10;
            this.label10.Text = "Age Group To";
            // 
            // txtAgeGroupFrom
            // 
            this.txtAgeGroupFrom.Location = new System.Drawing.Point(3, 83);
            this.txtAgeGroupFrom.Name = "txtAgeGroupFrom";
            this.txtAgeGroupFrom.Size = new System.Drawing.Size(256, 22);
            this.txtAgeGroupFrom.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(3, 63);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(208, 14);
            this.label6.TabIndex = 8;
            this.label6.Text = "Age Group From";
            // 
            // label7
            // 
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(3, 5);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(208, 14);
            this.label7.TabIndex = 7;
            this.label7.Text = "Gender";
            // 
            // dateTimePicker4
            // 
            this.dateTimePicker4.Checked = false;
            this.dateTimePicker4.Location = new System.Drawing.Point(293, 297);
            this.dateTimePicker4.Name = "dateTimePicker4";
            this.dateTimePicker4.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker4.TabIndex = 3;
            this.dateTimePicker4.Value = new System.DateTime(2020, 11, 6, 6, 6, 12, 116);
            // 
            // comboBox10
            // 
            this.comboBox10.Location = new System.Drawing.Point(174, 245);
            this.comboBox10.Name = "comboBox10";
            this.comboBox10.Size = new System.Drawing.Size(120, 22);
            this.comboBox10.TabIndex = 2;
            // 
            // cbGender
            // 
            this.cbGender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.cbGender.Location = new System.Drawing.Point(3, 25);
            this.cbGender.Name = "cbGender";
            this.cbGender.Size = new System.Drawing.Size(374, 22);
            this.cbGender.TabIndex = 1;
            // 
            // txtGender
            // 
            this.txtGender.AutoSize = false;
            this.txtGender.Location = new System.Drawing.Point(383, 25);
            this.txtGender.Name = "txtGender";
            this.txtGender.Size = new System.Drawing.Size(131, 22);
            this.txtGender.TabIndex = 0;
            // 
            // panel7
            // 
            this.panel7.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel7.Controls.Add(this.ckSurburb);
            this.panel7.Controls.Add(this.label5);
            this.panel7.Controls.Add(this.label4);
            this.panel7.Controls.Add(this.cbHomeCell);
            this.panel7.Controls.Add(this.txtHomeCell);
            this.panel7.Controls.Add(this.dateTimePicker3);
            this.panel7.Controls.Add(this.comboBox7);
            this.panel7.Controls.Add(this.cbSurburb);
            this.panel7.Controls.Add(this.txtSurburb);
            this.panel7.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel7.HeaderForeColor = System.Drawing.Color.Black;
            this.panel7.Location = new System.Drawing.Point(3, 142);
            this.panel7.Name = "panel7";
            this.panel7.ShowCloseButton = false;
            this.panel7.ShowHeader = true;
            this.panel7.Size = new System.Drawing.Size(523, 157);
            this.panel7.TabIndex = 7;
            this.panel7.TabStop = true;
            this.panel7.Text = "Area or Zone & Home Cell";
            // 
            // ckSurburb
            // 
            this.ckSurburb.Location = new System.Drawing.Point(3, 89);
            this.ckSurburb.Name = "ckSurburb";
            this.ckSurburb.Size = new System.Drawing.Size(449, 22);
            this.ckSurburb.TabIndex = 9;
            this.ckSurburb.Text = "Surburb / Area Classification Not Available At The Time Of Data Capture";
            // 
            // label5
            // 
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(260, 14);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(147, 14);
            this.label5.TabIndex = 8;
            this.label5.Text = "Home Cell";
            // 
            // label4
            // 
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(3, 14);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(208, 14);
            this.label4.TabIndex = 7;
            this.label4.Text = "Surburb / Area Classification";
            // 
            // cbHomeCell
            // 
            this.cbHomeCell.Location = new System.Drawing.Point(260, 34);
            this.cbHomeCell.Name = "cbHomeCell";
            this.cbHomeCell.Size = new System.Drawing.Size(258, 22);
            this.cbHomeCell.TabIndex = 5;
            // 
            // txtHomeCell
            // 
            this.txtHomeCell.Location = new System.Drawing.Point(260, 61);
            this.txtHomeCell.Name = "txtHomeCell";
            this.txtHomeCell.Size = new System.Drawing.Size(258, 22);
            this.txtHomeCell.TabIndex = 4;
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.Checked = false;
            this.dateTimePicker3.Location = new System.Drawing.Point(293, 297);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker3.TabIndex = 3;
            this.dateTimePicker3.Value = new System.DateTime(2020, 11, 6, 6, 6, 12, 116);
            // 
            // comboBox7
            // 
            this.comboBox7.Location = new System.Drawing.Point(174, 245);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(120, 22);
            this.comboBox7.TabIndex = 2;
            // 
            // cbSurburb
            // 
            this.cbSurburb.Items.AddRange(new object[] {
            "Abelempke",
            "Accra - Central",
            "Achimota",
            "Adenta",
            "Ashongman Estates",
            "Awoshie",
            "Chorkor",
            "Circle"});
            this.cbSurburb.Location = new System.Drawing.Point(3, 34);
            this.cbSurburb.Name = "cbSurburb";
            this.cbSurburb.Size = new System.Drawing.Size(240, 22);
            this.cbSurburb.TabIndex = 1;
            // 
            // txtSurburb
            // 
            this.txtSurburb.Location = new System.Drawing.Point(3, 61);
            this.txtSurburb.Name = "txtSurburb";
            this.txtSurburb.Size = new System.Drawing.Size(240, 22);
            this.txtSurburb.TabIndex = 0;
            // 
            // panel6
            // 
            this.panel6.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel6.Controls.Add(this.label3);
            this.panel6.Controls.Add(this.cbDepartment);
            this.panel6.Controls.Add(this.txtDepartment);
            this.panel6.Controls.Add(this.label2);
            this.panel6.Controls.Add(this.dateTimePicker2);
            this.panel6.Controls.Add(this.comboBox3);
            this.panel6.Controls.Add(this.cbMinistryChurch);
            this.panel6.Controls.Add(this.txtMinistryChurch);
            this.panel6.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel6.HeaderForeColor = System.Drawing.Color.Black;
            this.panel6.Location = new System.Drawing.Point(3, 3);
            this.panel6.Name = "panel6";
            this.panel6.ShowCloseButton = false;
            this.panel6.ShowHeader = true;
            this.panel6.Size = new System.Drawing.Size(523, 136);
            this.panel6.TabIndex = 4;
            this.panel6.TabStop = true;
            this.panel6.Text = "Ministry & Department";
            // 
            // label3
            // 
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(258, 14);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(165, 14);
            this.label3.TabIndex = 6;
            this.label3.Text = "Department";
            // 
            // cbDepartment
            // 
            this.cbDepartment.Items.AddRange(new object[] {
            "Choir",
            "Perez Theatre Act",
            "Prayer",
            "Technical",
            "Stay Connected",
            "Minstrels",
            "Media",
            "Ushering"});
            this.cbDepartment.Location = new System.Drawing.Point(260, 34);
            this.cbDepartment.Name = "cbDepartment";
            this.cbDepartment.Size = new System.Drawing.Size(258, 22);
            this.cbDepartment.TabIndex = 5;
            // 
            // txtDepartment
            // 
            this.txtDepartment.Location = new System.Drawing.Point(260, 61);
            this.txtDepartment.Name = "txtDepartment";
            this.txtDepartment.Size = new System.Drawing.Size(258, 22);
            this.txtDepartment.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(1, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(147, 14);
            this.label2.TabIndex = 1;
            this.label2.Text = "Ministry/Church";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Checked = false;
            this.dateTimePicker2.Location = new System.Drawing.Point(293, 297);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(200, 22);
            this.dateTimePicker2.TabIndex = 3;
            this.dateTimePicker2.Value = new System.DateTime(2020, 11, 6, 6, 6, 12, 116);
            // 
            // comboBox3
            // 
            this.comboBox3.Location = new System.Drawing.Point(174, 245);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(120, 22);
            this.comboBox3.TabIndex = 2;
            // 
            // cbMinistryChurch
            // 
            this.cbMinistryChurch.Items.AddRange(new object[] {
            "Adults Service - Dome",
            "French Service",
            "Timothy Generation",
            "Twi Service"});
            this.cbMinistryChurch.Location = new System.Drawing.Point(3, 34);
            this.cbMinistryChurch.Name = "cbMinistryChurch";
            this.cbMinistryChurch.Size = new System.Drawing.Size(240, 22);
            this.cbMinistryChurch.TabIndex = 1;
            // 
            // txtMinistryChurch
            // 
            this.txtMinistryChurch.Location = new System.Drawing.Point(3, 61);
            this.txtMinistryChurch.Name = "txtMinistryChurch";
            this.txtMinistryChurch.Size = new System.Drawing.Size(240, 22);
            this.txtMinistryChurch.TabIndex = 0;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(321, 93);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 22);
            this.textBox1.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel4.Controls.Add(this.linkLabelPeriodicMemberDecision);
            this.panel4.Controls.Add(this.linkLabelPeriodicAreaZone);
            this.panel4.Controls.Add(this.linkLabelPeriodicMinistry);
            this.panel4.Controls.Add(this.linkLabelPeriodicGlobal);
            this.panel4.Controls.Add(this.label13);
            this.panel4.Controls.Add(this.linkLabelAgeGroup);
            this.panel4.Controls.Add(this.linkLabelGenderSummaryEntireChurch);
            this.panel4.Controls.Add(this.linkLabelGenderEntireChurch);
            this.panel4.Controls.Add(this.linkLabelGenderAndMinistry);
            this.panel4.Controls.Add(this.label12);
            this.panel4.Controls.Add(this.linkLabelMembershipDistribution);
            this.panel4.Controls.Add(this.linkLabelEntireChurchSummaryGroupByDepartment);
            this.panel4.Controls.Add(this.linkLabelEntireChurchSummaryGroupByMemberType);
            this.panel4.Controls.Add(this.linkLabelEntireChurch);
            this.panel4.Controls.Add(this.linkLabelHomeCell);
            this.panel4.Controls.Add(this.linkLabelAreaZoneClass);
            this.panel4.Controls.Add(this.linkLabelMinistryAndDepartment);
            this.panel4.Controls.Add(this.linkLabelListByMinistry);
            this.panel4.Controls.Add(this.linkLabelRefreshReport);
            this.panel4.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel4.HeaderForeColor = System.Drawing.Color.Black;
            this.panel4.Location = new System.Drawing.Point(540, 3);
            this.panel4.Name = "panel4";
            this.panel4.ShowCloseButton = false;
            this.panel4.ShowHeader = true;
            this.panel4.Size = new System.Drawing.Size(498, 676);
            this.panel4.TabIndex = 3;
            this.panel4.TabStop = true;
            this.panel4.Text = "Report Parameters";
            // 
            // linkLabelPeriodicMemberDecision
            // 
            this.linkLabelPeriodicMemberDecision.AutoSize = true;
            this.linkLabelPeriodicMemberDecision.Location = new System.Drawing.Point(35, 517);
            this.linkLabelPeriodicMemberDecision.Name = "linkLabelPeriodicMemberDecision";
            this.linkLabelPeriodicMemberDecision.Size = new System.Drawing.Size(285, 15);
            this.linkLabelPeriodicMemberDecision.TabIndex = 19;
            this.linkLabelPeriodicMemberDecision.Text = "Periodic Pre-Member  List - By Member Decision";
            // 
            // linkLabelPeriodicAreaZone
            // 
            this.linkLabelPeriodicAreaZone.AutoSize = true;
            this.linkLabelPeriodicAreaZone.Location = new System.Drawing.Point(33, 496);
            this.linkLabelPeriodicAreaZone.Name = "linkLabelPeriodicAreaZone";
            this.linkLabelPeriodicAreaZone.Size = new System.Drawing.Size(252, 15);
            this.linkLabelPeriodicAreaZone.TabIndex = 18;
            this.linkLabelPeriodicAreaZone.Text = "Periodic Pre-Member  List - By Area / Zone";
            // 
            // linkLabelPeriodicMinistry
            // 
            this.linkLabelPeriodicMinistry.AutoSize = true;
            this.linkLabelPeriodicMinistry.Location = new System.Drawing.Point(33, 475);
            this.linkLabelPeriodicMinistry.Name = "linkLabelPeriodicMinistry";
            this.linkLabelPeriodicMinistry.Size = new System.Drawing.Size(229, 15);
            this.linkLabelPeriodicMinistry.TabIndex = 17;
            this.linkLabelPeriodicMinistry.Text = "Periodic Pre-Member  List - By Ministry";
            // 
            // linkLabelPeriodicGlobal
            // 
            this.linkLabelPeriodicGlobal.AutoSize = true;
            this.linkLabelPeriodicGlobal.Location = new System.Drawing.Point(35, 451);
            this.linkLabelPeriodicGlobal.Name = "linkLabelPeriodicGlobal";
            this.linkLabelPeriodicGlobal.Size = new System.Drawing.Size(203, 15);
            this.linkLabelPeriodicGlobal.TabIndex = 16;
            this.linkLabelPeriodicGlobal.Text = "Periodic Pre-Member  List - Global";
            // 
            // label13
            // 
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(35, 417);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(147, 14);
            this.label13.TabIndex = 15;
            this.label13.Text = "-------";
            // 
            // linkLabelAgeGroup
            // 
            this.linkLabelAgeGroup.AutoSize = true;
            this.linkLabelAgeGroup.Location = new System.Drawing.Point(35, 361);
            this.linkLabelAgeGroup.Name = "linkLabelAgeGroup";
            this.linkLabelAgeGroup.Size = new System.Drawing.Size(160, 15);
            this.linkLabelAgeGroup.TabIndex = 14;
            this.linkLabelAgeGroup.Text = "Member List By Age Group";
            // 
            // linkLabelGenderSummaryEntireChurch
            // 
            this.linkLabelGenderSummaryEntireChurch.AutoSize = true;
            this.linkLabelGenderSummaryEntireChurch.Location = new System.Drawing.Point(35, 340);
            this.linkLabelGenderSummaryEntireChurch.Name = "linkLabelGenderSummaryEntireChurch";
            this.linkLabelGenderSummaryEntireChurch.Size = new System.Drawing.Size(369, 15);
            this.linkLabelGenderSummaryEntireChurch.TabIndex = 13;
            this.linkLabelGenderSummaryEntireChurch.Text = "Member List - Entire Church ( Grouped By Gender - Summary )";
            // 
            // linkLabelGenderEntireChurch
            // 
            this.linkLabelGenderEntireChurch.AutoSize = true;
            this.linkLabelGenderEntireChurch.Location = new System.Drawing.Point(35, 318);
            this.linkLabelGenderEntireChurch.Name = "linkLabelGenderEntireChurch";
            this.linkLabelGenderEntireChurch.Size = new System.Drawing.Size(299, 15);
            this.linkLabelGenderEntireChurch.TabIndex = 12;
            this.linkLabelGenderEntireChurch.Text = "Member List By Gender - Entire Church ( Detailed )";
            // 
            // linkLabelGenderAndMinistry
            // 
            this.linkLabelGenderAndMinistry.AutoSize = true;
            this.linkLabelGenderAndMinistry.Location = new System.Drawing.Point(35, 297);
            this.linkLabelGenderAndMinistry.Name = "linkLabelGenderAndMinistry";
            this.linkLabelGenderAndMinistry.Size = new System.Drawing.Size(201, 15);
            this.linkLabelGenderAndMinistry.TabIndex = 11;
            this.linkLabelGenderAndMinistry.Text = "Member List By Gender & Ministry";
            // 
            // label12
            // 
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(35, 261);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(147, 14);
            this.label12.TabIndex = 10;
            this.label12.Text = "-------";
            // 
            // linkLabelMembershipDistribution
            // 
            this.linkLabelMembershipDistribution.AutoSize = true;
            this.linkLabelMembershipDistribution.Location = new System.Drawing.Point(35, 215);
            this.linkLabelMembershipDistribution.Name = "linkLabelMembershipDistribution";
            this.linkLabelMembershipDistribution.Size = new System.Drawing.Size(148, 15);
            this.linkLabelMembershipDistribution.TabIndex = 9;
            this.linkLabelMembershipDistribution.Text = "Membership Distrubution";
            // 
            // linkLabelEntireChurchSummaryGroupByDepartment
            // 
            this.linkLabelEntireChurchSummaryGroupByDepartment.AutoSize = true;
            this.linkLabelEntireChurchSummaryGroupByDepartment.Location = new System.Drawing.Point(35, 194);
            this.linkLabelEntireChurchSummaryGroupByDepartment.Name = "linkLabelEntireChurchSummaryGroupByDepartment";
            this.linkLabelEntireChurchSummaryGroupByDepartment.Size = new System.Drawing.Size(407, 15);
            this.linkLabelEntireChurchSummaryGroupByDepartment.TabIndex = 8;
            this.linkLabelEntireChurchSummaryGroupByDepartment.Text = "Active Members Entire Church - Summary ( Grouped By Department )";
            // 
            // linkLabelEntireChurchSummaryGroupByMemberType
            // 
            this.linkLabelEntireChurchSummaryGroupByMemberType.AutoSize = true;
            this.linkLabelEntireChurchSummaryGroupByMemberType.Location = new System.Drawing.Point(35, 172);
            this.linkLabelEntireChurchSummaryGroupByMemberType.Name = "linkLabelEntireChurchSummaryGroupByMemberType";
            this.linkLabelEntireChurchSummaryGroupByMemberType.Size = new System.Drawing.Size(420, 15);
            this.linkLabelEntireChurchSummaryGroupByMemberType.TabIndex = 7;
            this.linkLabelEntireChurchSummaryGroupByMemberType.Text = "Active Members Entire Church - Summary ( Grouped By Member Type )";
            // 
            // linkLabelEntireChurch
            // 
            this.linkLabelEntireChurch.AutoSize = true;
            this.linkLabelEntireChurch.Location = new System.Drawing.Point(35, 146);
            this.linkLabelEntireChurch.Name = "linkLabelEntireChurch";
            this.linkLabelEntireChurch.Size = new System.Drawing.Size(263, 15);
            this.linkLabelEntireChurch.TabIndex = 6;
            this.linkLabelEntireChurch.Text = "Active Members - Entire Church - ( Detailed )";
            // 
            // linkLabelHomeCell
            // 
            this.linkLabelHomeCell.AutoSize = true;
            this.linkLabelHomeCell.Location = new System.Drawing.Point(35, 122);
            this.linkLabelHomeCell.Name = "linkLabelHomeCell";
            this.linkLabelHomeCell.Size = new System.Drawing.Size(272, 15);
            this.linkLabelHomeCell.TabIndex = 5;
            this.linkLabelHomeCell.Text = "Active Member List By Home Cell - ( Detailed )";
            // 
            // linkLabelAreaZoneClass
            // 
            this.linkLabelAreaZoneClass.AutoSize = true;
            this.linkLabelAreaZoneClass.Location = new System.Drawing.Point(35, 97);
            this.linkLabelAreaZoneClass.Name = "linkLabelAreaZoneClass";
            this.linkLabelAreaZoneClass.Size = new System.Drawing.Size(316, 15);
            this.linkLabelAreaZoneClass.TabIndex = 4;
            this.linkLabelAreaZoneClass.Text = "Active Member List By Area / Zone Class - ( Detailed )";
            // 
            // linkLabelMinistryAndDepartment
            // 
            this.linkLabelMinistryAndDepartment.AutoSize = true;
            this.linkLabelMinistryAndDepartment.Location = new System.Drawing.Point(35, 74);
            this.linkLabelMinistryAndDepartment.Name = "linkLabelMinistryAndDepartment";
            this.linkLabelMinistryAndDepartment.Size = new System.Drawing.Size(340, 15);
            this.linkLabelMinistryAndDepartment.TabIndex = 3;
            this.linkLabelMinistryAndDepartment.Text = "Active Member List By Ministry & Department - ( Detailed )";
            // 
            // linkLabelListByMinistry
            // 
            this.linkLabelListByMinistry.AutoSize = true;
            this.linkLabelListByMinistry.Location = new System.Drawing.Point(35, 47);
            this.linkLabelListByMinistry.Name = "linkLabelListByMinistry";
            this.linkLabelListByMinistry.Size = new System.Drawing.Size(256, 15);
            this.linkLabelListByMinistry.TabIndex = 1;
            this.linkLabelListByMinistry.Text = "Active Member List By Ministry - ( Detailed )";
            // 
            // linkLabelRefreshReport
            // 
            this.linkLabelRefreshReport.AutoSize = true;
            this.linkLabelRefreshReport.Location = new System.Drawing.Point(35, 23);
            this.linkLabelRefreshReport.Name = "linkLabelRefreshReport";
            this.linkLabelRefreshReport.Size = new System.Drawing.Size(92, 15);
            this.linkLabelRefreshReport.TabIndex = 0;
            this.linkLabelRefreshReport.Text = "Refresh Report";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightBlue;
            this.panel2.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = Wisej.Web.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1046, 41);
            this.panel2.TabIndex = 1;
            this.panel2.TabStop = true;
            // 
            // label1
            // 
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(32, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(145, 14);
            this.label1.TabIndex = 0;
            this.label1.Text = "MEMBERS REPORTS";
            // 
            // ucMembersInfoMembersReport
            // 
            this.Controls.Add(this.panel1);
            this.Name = "ucMembersInfoMembersReport";
            this.Size = new System.Drawing.Size(1086, 757);
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.Panel panel1;
        private Wisej.Web.Panel panel3;
        private Wisej.Web.Panel panel5;
        private Wisej.Web.Panel panel4;
        private Wisej.Web.Panel panel2;
        private Wisej.Web.Label label1;
        private Wisej.Web.Panel panel9;
        private Wisej.Web.Label label11;
        private Wisej.Web.DateTimePicker dtpTo;
        private Wisej.Web.Label label8;
        private Wisej.Web.DateTimePicker dtpFrom;
        private Wisej.Web.Label label9;
        private Wisej.Web.DateTimePicker dateTimePicker5;
        private Wisej.Web.ComboBox comboBox13;
        private Wisej.Web.ComboBox cbPreMemberType;
        private Wisej.Web.Panel panel8;
        private Wisej.Web.TextBox txtAgeGroupTo;
        private Wisej.Web.Label label10;
        private Wisej.Web.TextBox txtAgeGroupFrom;
        private Wisej.Web.Label label6;
        private Wisej.Web.Label label7;
        private Wisej.Web.DateTimePicker dateTimePicker4;
        private Wisej.Web.ComboBox comboBox10;
        private Wisej.Web.ComboBox cbGender;
        private Wisej.Web.TextBox txtGender;
        private Wisej.Web.Panel panel7;
        private Wisej.Web.CheckBox ckSurburb;
        private Wisej.Web.Label label5;
        private Wisej.Web.Label label4;
        private Wisej.Web.ComboBox cbHomeCell;
        private Wisej.Web.TextBox txtHomeCell;
        private Wisej.Web.DateTimePicker dateTimePicker3;
        private Wisej.Web.ComboBox comboBox7;
        private Wisej.Web.ComboBox cbSurburb;
        private Wisej.Web.TextBox txtSurburb;
        private Wisej.Web.Panel panel6;
        private Wisej.Web.Label label3;
        private Wisej.Web.ComboBox cbDepartment;
        private Wisej.Web.TextBox txtDepartment;
        private Wisej.Web.Label label2;
        private Wisej.Web.DateTimePicker dateTimePicker2;
        private Wisej.Web.ComboBox comboBox3;
        private Wisej.Web.ComboBox cbMinistryChurch;
        private Wisej.Web.TextBox txtMinistryChurch;
        private Wisej.Web.TextBox textBox1;
        private Wisej.Web.Label label13;
        private Wisej.Web.LinkLabel linkLabelAgeGroup;
        private Wisej.Web.LinkLabel linkLabelGenderSummaryEntireChurch;
        private Wisej.Web.LinkLabel linkLabelGenderEntireChurch;
        private Wisej.Web.LinkLabel linkLabelGenderAndMinistry;
        private Wisej.Web.Label label12;
        private Wisej.Web.LinkLabel linkLabelMembershipDistribution;
        private Wisej.Web.LinkLabel linkLabelEntireChurchSummaryGroupByDepartment;
        private Wisej.Web.LinkLabel linkLabelEntireChurchSummaryGroupByMemberType;
        private Wisej.Web.LinkLabel linkLabelEntireChurch;
        private Wisej.Web.LinkLabel linkLabelHomeCell;
        private Wisej.Web.LinkLabel linkLabelAreaZoneClass;
        private Wisej.Web.LinkLabel linkLabelMinistryAndDepartment;
        private Wisej.Web.LinkLabel linkLabelListByMinistry;
        private Wisej.Web.LinkLabel linkLabelRefreshReport;
        private Wisej.Web.LinkLabel linkLabelPeriodicMemberDecision;
        private Wisej.Web.LinkLabel linkLabelPeriodicAreaZone;
        private Wisej.Web.LinkLabel linkLabelPeriodicMinistry;
        private Wisej.Web.LinkLabel linkLabelPeriodicGlobal;
        private Wisej.Web.Button btnReportPreview;
        private Wisej.Web.Button btnTitheList;
    }
}
