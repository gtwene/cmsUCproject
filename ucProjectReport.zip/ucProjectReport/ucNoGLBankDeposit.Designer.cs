﻿namespace UCProject
{
    partial class ucNoGLBankDeposit
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new Wisej.Web.Panel();
            this.panel2 = new Wisej.Web.Panel();
            this.panel3 = new Wisej.Web.Panel();
            this.panel4 = new Wisej.Web.Panel();
            this.panel5 = new Wisej.Web.Panel();
            this.panel6 = new Wisej.Web.Panel();
            this.toolBar1 = new Wisej.Web.ToolBar();
            this.rbNoGLCashAccount = new Wisej.Web.RadioButton();
            this.rbNoGLBankAccount = new Wisej.Web.RadioButton();
            this.btnViewAccount = new Wisej.Web.Button();
            this.label1 = new Wisej.Web.Label();
            this.label3 = new Wisej.Web.Label();
            this.txtBankAccountTitle = new Wisej.Web.TextBox();
            this.txtBankAccountNo = new Wisej.Web.TextBox();
            this.txtDebitSmall = new Wisej.Web.TextBox();
            this.txtDebitAccountCurrency = new Wisej.Web.TextBox();
            this.label2 = new Wisej.Web.Label();
            this.txtCashAccountCurrency = new Wisej.Web.TextBox();
            this.label4 = new Wisej.Web.Label();
            this.txtCashSmall = new Wisej.Web.TextBox();
            this.txtCashAccountTitle = new Wisej.Web.TextBox();
            this.label5 = new Wisej.Web.Label();
            this.txtCashAccountNo = new Wisej.Web.TextBox();
            this.label6 = new Wisej.Web.Label();
            this.dtpActualDepositDate = new Wisej.Web.DateTimePicker();
            this.label7 = new Wisej.Web.Label();
            this.label8 = new Wisej.Web.Label();
            this.txtTransactionAmount = new Wisej.Web.TextBox();
            this.label9 = new Wisej.Web.Label();
            this.txtNarration = new Wisej.Web.TextBox();
            this.btnPostTrans = new Wisej.Web.ToolBarButton();
            this.btnCancelTrans = new Wisej.Web.ToolBarButton();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel1.Controls.Add(this.btnViewAccount);
            this.panel1.Controls.Add(this.rbNoGLBankAccount);
            this.panel1.Controls.Add(this.rbNoGLCashAccount);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1051, 458);
            this.panel1.TabIndex = 0;
            this.panel1.TabStop = true;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((Wisej.Web.AnchorStyles)(((Wisej.Web.AnchorStyles.Top | Wisej.Web.AnchorStyles.Left) 
            | Wisej.Web.AnchorStyles.Right)));
            this.panel2.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel2.Location = new System.Drawing.Point(3, 54);
            this.panel2.Name = "panel2";
            this.panel2.ShowCloseButton = false;
            this.panel2.ShowHeader = true;
            this.panel2.Size = new System.Drawing.Size(459, 444);
            this.panel2.TabIndex = 0;
            this.panel2.TabStop = true;
            this.panel2.Text = "Bank Account";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel3.Controls.Add(this.toolBar1);
            this.panel3.Controls.Add(this.panel6);
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Location = new System.Drawing.Point(461, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(564, 494);
            this.panel3.TabIndex = 1;
            this.panel3.TabStop = true;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel4.Controls.Add(this.txtDebitAccountCurrency);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Controls.Add(this.txtDebitSmall);
            this.panel4.Controls.Add(this.txtBankAccountTitle);
            this.panel4.Controls.Add(this.label1);
            this.panel4.Controls.Add(this.txtBankAccountNo);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Location = new System.Drawing.Point(3, 3);
            this.panel4.Name = "panel4";
            this.panel4.ShowCloseButton = false;
            this.panel4.ShowHeader = true;
            this.panel4.Size = new System.Drawing.Size(556, 154);
            this.panel4.TabIndex = 1;
            this.panel4.TabStop = true;
            this.panel4.Text = "Bank Account";
            // 
            // panel5
            // 
            this.panel5.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel5.Controls.Add(this.txtCashAccountCurrency);
            this.panel5.Controls.Add(this.label5);
            this.panel5.Controls.Add(this.label4);
            this.panel5.Controls.Add(this.label6);
            this.panel5.Controls.Add(this.txtCashSmall);
            this.panel5.Controls.Add(this.txtCashAccountNo);
            this.panel5.Controls.Add(this.txtCashAccountTitle);
            this.panel5.Location = new System.Drawing.Point(2, 158);
            this.panel5.Name = "panel5";
            this.panel5.ShowCloseButton = false;
            this.panel5.ShowHeader = true;
            this.panel5.Size = new System.Drawing.Size(557, 161);
            this.panel5.TabIndex = 2;
            this.panel5.TabStop = true;
            this.panel5.Text = "Church Main Cash Account";
            // 
            // panel6
            // 
            this.panel6.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel6.Controls.Add(this.txtNarration);
            this.panel6.Controls.Add(this.label9);
            this.panel6.Controls.Add(this.txtTransactionAmount);
            this.panel6.Controls.Add(this.label8);
            this.panel6.Controls.Add(this.label7);
            this.panel6.Controls.Add(this.dtpActualDepositDate);
            this.panel6.Location = new System.Drawing.Point(2, 321);
            this.panel6.Name = "panel6";
            this.panel6.ShowCloseButton = false;
            this.panel6.ShowHeader = true;
            this.panel6.Size = new System.Drawing.Size(557, 127);
            this.panel6.TabIndex = 3;
            this.panel6.TabStop = true;
            this.panel6.Text = "Transaction Details";
            // 
            // toolBar1
            // 
            this.toolBar1.AutoSize = false;
            this.toolBar1.Buttons.AddRange(new Wisej.Web.ToolBarButton[] {
            this.btnPostTrans,
            this.btnCancelTrans});
            this.toolBar1.Dock = Wisej.Web.DockStyle.None;
            this.toolBar1.Location = new System.Drawing.Point(3, 448);
            this.toolBar1.Name = "toolBar1";
            this.toolBar1.Size = new System.Drawing.Size(556, 45);
            this.toolBar1.TabIndex = 4;
            this.toolBar1.TabStop = false;
            // 
            // rbNoGLCashAccount
            // 
            this.rbNoGLCashAccount.Location = new System.Drawing.Point(161, 19);
            this.rbNoGLCashAccount.Name = "rbNoGLCashAccount";
            this.rbNoGLCashAccount.Size = new System.Drawing.Size(154, 22);
            this.rbNoGLCashAccount.TabIndex = 2;
            this.rbNoGLCashAccount.TabStop = true;
            this.rbNoGLCashAccount.Text = "No GL Cash Account";
            // 
            // rbNoGLBankAccount
            // 
            this.rbNoGLBankAccount.Location = new System.Drawing.Point(3, 19);
            this.rbNoGLBankAccount.Name = "rbNoGLBankAccount";
            this.rbNoGLBankAccount.Size = new System.Drawing.Size(153, 22);
            this.rbNoGLBankAccount.TabIndex = 3;
            this.rbNoGLBankAccount.TabStop = true;
            this.rbNoGLBankAccount.Text = "No GL Bank Account";
            // 
            // btnViewAccount
            // 
            this.btnViewAccount.Location = new System.Drawing.Point(321, 17);
            this.btnViewAccount.Name = "btnViewAccount";
            this.btnViewAccount.Size = new System.Drawing.Size(134, 27);
            this.btnViewAccount.TabIndex = 4;
            this.btnViewAccount.Text = "View Accounts";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Bank Account Title";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(4, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(141, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Debit Account Currency";
            // 
            // txtBankAccountTitle
            // 
            this.txtBankAccountTitle.LabelText = "";
            this.txtBankAccountTitle.Location = new System.Drawing.Point(3, 15);
            this.txtBankAccountTitle.Name = "txtBankAccountTitle";
            this.txtBankAccountTitle.Size = new System.Drawing.Size(548, 22);
            this.txtBankAccountTitle.TabIndex = 3;
            // 
            // txtBankAccountNo
            // 
            this.txtBankAccountNo.LabelText = "";
            this.txtBankAccountNo.Location = new System.Drawing.Point(3, 55);
            this.txtBankAccountNo.Name = "txtBankAccountNo";
            this.txtBankAccountNo.Size = new System.Drawing.Size(548, 22);
            this.txtBankAccountNo.TabIndex = 4;
            // 
            // txtDebitSmall
            // 
            this.txtDebitSmall.LabelText = "";
            this.txtDebitSmall.Location = new System.Drawing.Point(3, 96);
            this.txtDebitSmall.Name = "txtDebitSmall";
            this.txtDebitSmall.Size = new System.Drawing.Size(97, 22);
            this.txtDebitSmall.TabIndex = 5;
            // 
            // txtDebitAccountCurrency
            // 
            this.txtDebitAccountCurrency.LabelText = "";
            this.txtDebitAccountCurrency.Location = new System.Drawing.Point(106, 96);
            this.txtDebitAccountCurrency.Name = "txtDebitAccountCurrency";
            this.txtDebitAccountCurrency.Size = new System.Drawing.Size(445, 22);
            this.txtDebitAccountCurrency.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(4, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 15);
            this.label2.TabIndex = 4;
            this.label2.Text = "Bank Account No. ";
            // 
            // txtCashAccountCurrency
            // 
            this.txtCashAccountCurrency.LabelText = "";
            this.txtCashAccountCurrency.Location = new System.Drawing.Point(84, 103);
            this.txtCashAccountCurrency.Name = "txtCashAccountCurrency";
            this.txtCashAccountCurrency.Size = new System.Drawing.Size(468, 22);
            this.txtCashAccountCurrency.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(5, 43);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 15);
            this.label4.TabIndex = 10;
            this.label4.Text = "Cash Account No. ";
            // 
            // txtCashSmall
            // 
            this.txtCashSmall.LabelText = "";
            this.txtCashSmall.Location = new System.Drawing.Point(4, 103);
            this.txtCashSmall.Name = "txtCashSmall";
            this.txtCashSmall.Size = new System.Drawing.Size(74, 22);
            this.txtCashSmall.TabIndex = 12;
            // 
            // txtCashAccountTitle
            // 
            this.txtCashAccountTitle.LabelText = "";
            this.txtCashAccountTitle.Location = new System.Drawing.Point(4, 18);
            this.txtCashAccountTitle.Name = "txtCashAccountTitle";
            this.txtCashAccountTitle.Size = new System.Drawing.Size(548, 22);
            this.txtCashAccountTitle.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(5, 3);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(113, 15);
            this.label5.TabIndex = 7;
            this.label5.Text = "Cash Account Title";
            // 
            // txtCashAccountNo
            // 
            this.txtCashAccountNo.LabelText = "";
            this.txtCashAccountNo.Location = new System.Drawing.Point(4, 60);
            this.txtCashAccountNo.Name = "txtCashAccountNo";
            this.txtCashAccountNo.Size = new System.Drawing.Size(548, 22);
            this.txtCashAccountNo.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(5, 84);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(141, 15);
            this.label6.TabIndex = 8;
            this.label6.Text = "Cash Account Currency";
            // 
            // dtpActualDepositDate
            // 
            this.dtpActualDepositDate.Checked = false;
            this.dtpActualDepositDate.LabelText = "";
            this.dtpActualDepositDate.Location = new System.Drawing.Point(3, 16);
            this.dtpActualDepositDate.Name = "dtpActualDepositDate";
            this.dtpActualDepositDate.Size = new System.Drawing.Size(200, 22);
            this.dtpActualDepositDate.TabIndex = 0;
            this.dtpActualDepositDate.Value = new System.DateTime(2020, 12, 15, 10, 40, 33, 952);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(4, 1);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(118, 15);
            this.label7.TabIndex = 14;
            this.label7.Text = "Actual Deposit Date";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(215, 1);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(120, 15);
            this.label8.TabIndex = 15;
            this.label8.Text = "Transaction Amount";
            // 
            // txtTransactionAmount
            // 
            this.txtTransactionAmount.LabelText = "";
            this.txtTransactionAmount.Location = new System.Drawing.Point(215, 15);
            this.txtTransactionAmount.Name = "txtTransactionAmount";
            this.txtTransactionAmount.Size = new System.Drawing.Size(336, 22);
            this.txtTransactionAmount.TabIndex = 14;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(4, 38);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(57, 15);
            this.label9.TabIndex = 16;
            this.label9.Text = "Narration";
            // 
            // txtNarration
            // 
            this.txtNarration.LabelText = "";
            this.txtNarration.Location = new System.Drawing.Point(4, 53);
            this.txtNarration.Multiline = true;
            this.txtNarration.Name = "txtNarration";
            this.txtNarration.Size = new System.Drawing.Size(547, 41);
            this.txtNarration.TabIndex = 17;
            // 
            // btnPostTrans
            // 
            this.btnPostTrans.ImageSource = "ajax-loader";
            this.btnPostTrans.Name = "btnPostTrans";
            this.btnPostTrans.Text = "Post Transaction";
            this.btnPostTrans.Click += new System.EventHandler(this.btnPostTrans_Click);
            // 
            // btnCancelTrans
            // 
            this.btnCancelTrans.ImageSource = "tab-close";
            this.btnCancelTrans.Name = "btnCancelTrans";
            this.btnCancelTrans.Text = "Cancel Transaction";
            this.btnCancelTrans.Click += new System.EventHandler(this.btnCancelTrans_Click);
            // 
            // ucNoGLBankDeposit
            // 
            this.Controls.Add(this.panel1);
            this.Name = "ucNoGLBankDeposit";
            this.Size = new System.Drawing.Size(1054, 502);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.Panel panel1;
        private Wisej.Web.Button btnViewAccount;
        private Wisej.Web.RadioButton rbNoGLBankAccount;
        private Wisej.Web.RadioButton rbNoGLCashAccount;
        private Wisej.Web.Panel panel3;
        private Wisej.Web.ToolBar toolBar1;
        private Wisej.Web.Panel panel6;
        private Wisej.Web.TextBox txtNarration;
        private Wisej.Web.Label label9;
        private Wisej.Web.TextBox txtTransactionAmount;
        private Wisej.Web.Label label8;
        private Wisej.Web.Label label7;
        private Wisej.Web.DateTimePicker dtpActualDepositDate;
        private Wisej.Web.Panel panel5;
        private Wisej.Web.TextBox txtCashAccountCurrency;
        private Wisej.Web.Label label5;
        private Wisej.Web.Label label4;
        private Wisej.Web.Label label6;
        private Wisej.Web.TextBox txtCashSmall;
        private Wisej.Web.TextBox txtCashAccountNo;
        private Wisej.Web.TextBox txtCashAccountTitle;
        private Wisej.Web.Panel panel4;
        private Wisej.Web.TextBox txtDebitAccountCurrency;
        private Wisej.Web.Label label2;
        private Wisej.Web.TextBox txtDebitSmall;
        private Wisej.Web.TextBox txtBankAccountTitle;
        private Wisej.Web.Label label1;
        private Wisej.Web.TextBox txtBankAccountNo;
        private Wisej.Web.Label label3;
        private Wisej.Web.Panel panel2;
        private Wisej.Web.ToolBarButton btnPostTrans;
        private Wisej.Web.ToolBarButton btnCancelTrans;
    }
}
