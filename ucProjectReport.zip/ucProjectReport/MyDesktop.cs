﻿using System;
using Wisej.Web;

namespace UCProject
{
    public partial class MyDesktop : Desktop
    {
        public MyDesktop()
        {
            InitializeComponent();
        }
    }
}
