﻿namespace UCProject
{
    partial class ucShepherdAssignment
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PShepherdAssignment = new Wisej.Web.Panel();
            this.btnExistingMembers = new Wisej.Web.Button();
            this.btnCreateFirstTimerOrNewConvert = new Wisej.Web.Button();
            this.btnFirstTimeNewConvert = new Wisej.Web.Button();
            this.panel3 = new Wisej.Web.Panel();
            this.cbGlobalMemberType = new Wisej.Web.ComboBox();
            this.txtMemberName = new Wisej.Web.TextBox();
            this.btnSearch = new Wisej.Web.Button();
            this.label4 = new Wisej.Web.Label();
            this.rbMemberType = new Wisej.Web.RadioButton();
            this.rbGlobal = new Wisej.Web.RadioButton();
            this.dtpTo = new Wisej.Web.DateTimePicker();
            this.dtpFrom = new Wisej.Web.DateTimePicker();
            this.label3 = new Wisej.Web.Label();
            this.label2 = new Wisej.Web.Label();
            this.panel4 = new Wisej.Web.Panel();
            this.panel2 = new Wisej.Web.Panel();
            this.label1 = new Wisej.Web.Label();
            this.PShepherdAssignment.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // PShepherdAssignment
            // 
            this.PShepherdAssignment.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.PShepherdAssignment.Controls.Add(this.btnExistingMembers);
            this.PShepherdAssignment.Controls.Add(this.btnCreateFirstTimerOrNewConvert);
            this.PShepherdAssignment.Controls.Add(this.btnFirstTimeNewConvert);
            this.PShepherdAssignment.Controls.Add(this.panel3);
            this.PShepherdAssignment.Controls.Add(this.panel2);
            this.PShepherdAssignment.Location = new System.Drawing.Point(3, 29);
            this.PShepherdAssignment.Name = "PShepherdAssignment";
            this.PShepherdAssignment.Size = new System.Drawing.Size(820, 441);
            this.PShepherdAssignment.TabIndex = 0;
            this.PShepherdAssignment.TabStop = true;
            // 
            // btnExistingMembers
            // 
            this.btnExistingMembers.BackColor = System.Drawing.Color.Gainsboro;
            this.btnExistingMembers.ForeColor = System.Drawing.Color.Black;
            this.btnExistingMembers.Location = new System.Drawing.Point(403, 37);
            this.btnExistingMembers.Name = "btnExistingMembers";
            this.btnExistingMembers.Size = new System.Drawing.Size(200, 27);
            this.btnExistingMembers.TabIndex = 4;
            this.btnExistingMembers.Text = "Existing Members";
            // 
            // btnCreateFirstTimerOrNewConvert
            // 
            this.btnCreateFirstTimerOrNewConvert.BackColor = System.Drawing.Color.Gainsboro;
            this.btnCreateFirstTimerOrNewConvert.ForeColor = System.Drawing.Color.Black;
            this.btnCreateFirstTimerOrNewConvert.Location = new System.Drawing.Point(201, 37);
            this.btnCreateFirstTimerOrNewConvert.Name = "btnCreateFirstTimerOrNewConvert";
            this.btnCreateFirstTimerOrNewConvert.Size = new System.Drawing.Size(200, 27);
            this.btnCreateFirstTimerOrNewConvert.TabIndex = 3;
            this.btnCreateFirstTimerOrNewConvert.Text = "Create First Time Or New Convert";
            this.btnCreateFirstTimerOrNewConvert.Click += new System.EventHandler(this.btnCreateFirstTimerOrNewConvert_Click);
            // 
            // btnFirstTimeNewConvert
            // 
            this.btnFirstTimeNewConvert.BackColor = System.Drawing.Color.Gainsboro;
            this.btnFirstTimeNewConvert.ForeColor = System.Drawing.Color.Black;
            this.btnFirstTimeNewConvert.Location = new System.Drawing.Point(0, 37);
            this.btnFirstTimeNewConvert.Name = "btnFirstTimeNewConvert";
            this.btnFirstTimeNewConvert.Size = new System.Drawing.Size(200, 27);
            this.btnFirstTimeNewConvert.TabIndex = 2;
            this.btnFirstTimeNewConvert.Text = "First Time / New Convert Search";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel3.Controls.Add(this.cbGlobalMemberType);
            this.panel3.Controls.Add(this.txtMemberName);
            this.panel3.Controls.Add(this.btnSearch);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.rbMemberType);
            this.panel3.Controls.Add(this.rbGlobal);
            this.panel3.Controls.Add(this.dtpTo);
            this.panel3.Controls.Add(this.dtpFrom);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Font = new System.Drawing.Font("@default", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.panel3.Location = new System.Drawing.Point(1, 63);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(812, 365);
            this.panel3.TabIndex = 2;
            this.panel3.TabStop = true;
            // 
            // cbGlobalMemberType
            // 
            this.cbGlobalMemberType.AutoSize = false;
            this.cbGlobalMemberType.LabelText = "";
            this.cbGlobalMemberType.Location = new System.Drawing.Point(8, 75);
            this.cbGlobalMemberType.Name = "cbGlobalMemberType";
            this.cbGlobalMemberType.Size = new System.Drawing.Size(250, 27);
            this.cbGlobalMemberType.TabIndex = 9;
            // 
            // txtMemberName
            // 
            this.txtMemberName.AutoSize = false;
            this.txtMemberName.LabelText = "";
            this.txtMemberName.Location = new System.Drawing.Point(328, 75);
            this.txtMemberName.Name = "txtMemberName";
            this.txtMemberName.Size = new System.Drawing.Size(240, 27);
            this.txtMemberName.TabIndex = 8;
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.Gainsboro;
            this.btnSearch.ForeColor = System.Drawing.Color.Black;
            this.btnSearch.ImageSource = "icon-search";
            this.btnSearch.Location = new System.Drawing.Point(597, 75);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(146, 27);
            this.btnSearch.TabIndex = 5;
            this.btnSearch.Text = "Search";
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("default, Arial Black", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(328, 59);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 15);
            this.label4.TabIndex = 7;
            this.label4.Text = "Member Name";
            // 
            // rbMemberType
            // 
            this.rbMemberType.Location = new System.Drawing.Point(129, 52);
            this.rbMemberType.Name = "rbMemberType";
            this.rbMemberType.Size = new System.Drawing.Size(112, 22);
            this.rbMemberType.TabIndex = 6;
            this.rbMemberType.TabStop = true;
            this.rbMemberType.Text = "Member Type";
            // 
            // rbGlobal
            // 
            this.rbGlobal.Location = new System.Drawing.Point(7, 52);
            this.rbGlobal.Name = "rbGlobal";
            this.rbGlobal.Size = new System.Drawing.Size(69, 22);
            this.rbGlobal.TabIndex = 5;
            this.rbGlobal.TabStop = true;
            this.rbGlobal.Text = "Global";
            // 
            // dtpTo
            // 
            this.dtpTo.Checked = false;
            this.dtpTo.LabelText = "";
            this.dtpTo.Location = new System.Drawing.Point(328, 6);
            this.dtpTo.Name = "dtpTo";
            this.dtpTo.Size = new System.Drawing.Size(200, 22);
            this.dtpTo.TabIndex = 4;
            this.dtpTo.Value = new System.DateTime(2020, 10, 14, 7, 33, 47, 915);
            // 
            // dtpFrom
            // 
            this.dtpFrom.Checked = false;
            this.dtpFrom.LabelText = "";
            this.dtpFrom.Location = new System.Drawing.Point(58, 5);
            this.dtpFrom.Name = "dtpFrom";
            this.dtpFrom.Size = new System.Drawing.Size(200, 22);
            this.dtpFrom.TabIndex = 3;
            this.dtpFrom.Value = new System.DateTime(2020, 10, 14, 7, 33, 47, 915);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("default, Arial Black", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(289, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(19, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "To";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("default, Arial Black", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(7, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "From ";
            // 
            // panel4
            // 
            this.panel4.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel4.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel4.HeaderForeColor = System.Drawing.Color.Black;
            this.panel4.Location = new System.Drawing.Point(3, 123);
            this.panel4.Name = "panel4";
            this.panel4.ShowHeader = true;
            this.panel4.Size = new System.Drawing.Size(804, 242);
            this.panel4.TabIndex = 1;
            this.panel4.TabStop = true;
            this.panel4.Text = "Search Results";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = Wisej.Web.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(818, 36);
            this.panel2.TabIndex = 1;
            this.panel2.TabStop = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("default, Arial Black", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Pixel);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(2, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(215, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "New Pre-member Data Entry";
            // 
            // ucShepherdAssignment
            // 
            this.Controls.Add(this.PShepherdAssignment);
            this.Name = "ucShepherdAssignment";
            this.Size = new System.Drawing.Size(835, 473);
            this.PShepherdAssignment.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.Panel PShepherdAssignment;
        private Wisej.Web.Button btnExistingMembers;
        private Wisej.Web.Button btnCreateFirstTimerOrNewConvert;
        private Wisej.Web.Button btnFirstTimeNewConvert;
        private Wisej.Web.Panel panel3;
        private Wisej.Web.ComboBox cbGlobalMemberType;
        private Wisej.Web.TextBox txtMemberName;
        private Wisej.Web.Button btnSearch;
        private Wisej.Web.Label label4;
        private Wisej.Web.RadioButton rbMemberType;
        private Wisej.Web.RadioButton rbGlobal;
        private Wisej.Web.DateTimePicker dtpTo;
        private Wisej.Web.DateTimePicker dtpFrom;
        private Wisej.Web.Label label3;
        private Wisej.Web.Label label2;
        private Wisej.Web.Panel panel4;
        private Wisej.Web.Panel panel2;
        private Wisej.Web.Label label1;
    }
}
