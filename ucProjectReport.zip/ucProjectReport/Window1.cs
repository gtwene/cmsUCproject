﻿
using System;
using Wisej.Web;

namespace UCProject
{
    public partial class Window1 : Form
    {
        public Window1()
        {
            InitializeComponent();
        }
        //Instantiate all ur controlsat the top here
        ucPro form1 = new ucPro();//ths line is the same as //Dim from1 as New ucPro
        private void btnProc_Click(object sender, EventArgs e)
        {
            //i will now call the form throught this event
            //u need 2 lne to call ur user control
            //1. Clear changeable panel
            panChnageable.Controls.Clear();
            //2.Add  new control to panel
            panChnageable.Controls.Add(form1);//tas all,please run it again

        }

        ucPreMember form2 = new ucPreMember();
        private void button1_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form2);
        }

        ucBulkSMS form3 = new ucBulkSMS();
        private void btnSMS_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form3);
        }

        ucUploadExistingMembers form4 = new ucUploadExistingMembers();
        private void btnUploadExisting_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form4);
        }

        ucApproveUploadedMembers form5 = new ucApproveUploadedMembers();
        private void btnApproveUploadedMembers_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form5);
        }

        ucPrememberManagerChuchAttendance form6 = new ucPrememberManagerChuchAttendance();
        private void button2_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form6);
        }

        ucShepherdAssignment form7 = new ucShepherdAssignment();
        private void button3_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form7);
        }

        ucExistingMember form8 = new ucExistingMember();
        private void button4_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form8);
        }

        ucTransitionToMembership form9 = new ucTransitionToMembership();
        private void button5_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form9);
        }

        ucPreMemberToMember form10 = new ucPreMemberToMember();
        private void button6_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form10);
        }

        ucTransitionToMembershipBatch form11 = new ucTransitionToMembershipBatch();
        private void button7_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form11);
        }

        UCCreateFirstTimerOrNewConvertForm form12 = new UCCreateFirstTimerOrNewConvertForm();
        private void button8_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form12);
        }

        ucMembersInfoMembersReport form13 = new ucMembersInfoMembersReport();
        private void button9_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form13);
        }

        ucMembersAnniversaryPeriodReport form14 = new ucMembersAnniversaryPeriodReport();
        private void button10_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form14);
        }

        ucChurchAttendanceReport form15 = new ucChurchAttendanceReport();
        private void button11_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form15);
        }

        ucMemberActivitiesReport form16 = new ucMemberActivitiesReport();
        private void button12_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form16);
        }

        ucMemberShipFormReport form17 = new ucMemberShipFormReport();
        private void button13_Click(object sender, EventArgs e)
        {
            panChnageable.Controls.Clear();
            panChnageable.Controls.Add(form17);
        }
    }
}
