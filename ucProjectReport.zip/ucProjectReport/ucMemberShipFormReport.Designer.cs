﻿namespace UCProject
{
    partial class ucMemberShipFormReport
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new Wisej.Web.Panel();
            this.panel2 = new Wisej.Web.Panel();
            this.panel3 = new Wisej.Web.Panel();
            this.panel4 = new Wisej.Web.Panel();
            this.panel5 = new Wisej.Web.Panel();
            this.panel6 = new Wisej.Web.Panel();
            this.panel7 = new Wisej.Web.Panel();
            this.label1 = new Wisej.Web.Label();
            this.btnReportPreview = new Wisej.Web.Button();
            this.btnTitheList = new Wisej.Web.Button();
            this.panel8 = new Wisej.Web.Panel();
            this.linkLabelPeriodicMinistryActivity = new Wisej.Web.LinkLabel();
            this.linkLabelPeriodicMemberActivity = new Wisej.Web.LinkLabel();
            this.linkLabelRefreshReport = new Wisej.Web.LinkLabel();
            this.linkLabelPreMemberDateForm = new Wisej.Web.LinkLabel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel8.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel1.Controls.Add(this.btnReportPreview);
            this.panel1.Controls.Add(this.btnTitheList);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1057, 486);
            this.panel1.TabIndex = 0;
            this.panel1.TabStop = true;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightBlue;
            this.panel2.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = Wisej.Web.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1055, 41);
            this.panel2.TabIndex = 1;
            this.panel2.TabStop = true;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Location = new System.Drawing.Point(3, 74);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1049, 402);
            this.panel3.TabIndex = 2;
            this.panel3.TabStop = true;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel4.Controls.Add(this.panel7);
            this.panel4.Controls.Add(this.panel6);
            this.panel4.Location = new System.Drawing.Point(5, 1);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(503, 391);
            this.panel4.TabIndex = 3;
            this.panel4.TabStop = true;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel5.Controls.Add(this.panel8);
            this.panel5.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel5.HeaderForeColor = System.Drawing.Color.Black;
            this.panel5.Location = new System.Drawing.Point(522, 8);
            this.panel5.Name = "panel5";
            this.panel5.ShowCloseButton = false;
            this.panel5.ShowHeader = true;
            this.panel5.Size = new System.Drawing.Size(524, 391);
            this.panel5.TabIndex = 4;
            this.panel5.TabStop = true;
            this.panel5.Text = "Report Parameters";
            // 
            // panel6
            // 
            this.panel6.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel6.Location = new System.Drawing.Point(8, 1);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(481, 96);
            this.panel6.TabIndex = 4;
            this.panel6.TabStop = true;
            // 
            // panel7
            // 
            this.panel7.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel7.Location = new System.Drawing.Point(8, 99);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(481, 287);
            this.panel7.TabIndex = 5;
            this.panel7.TabStop = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(7, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "MEMBERSHIP FORM";
            // 
            // btnReportPreview
            // 
            this.btnReportPreview.BackColor = System.Drawing.Color.Gainsboro;
            this.btnReportPreview.ForeColor = System.Drawing.Color.Black;
            this.btnReportPreview.Location = new System.Drawing.Point(201, 46);
            this.btnReportPreview.Name = "btnReportPreview";
            this.btnReportPreview.Size = new System.Drawing.Size(100, 27);
            this.btnReportPreview.TabIndex = 8;
            this.btnReportPreview.Text = "Report Preview";
            // 
            // btnTitheList
            // 
            this.btnTitheList.BackColor = System.Drawing.Color.Gainsboro;
            this.btnTitheList.ForeColor = System.Drawing.Color.Black;
            this.btnTitheList.Location = new System.Drawing.Point(5, 46);
            this.btnTitheList.Name = "btnTitheList";
            this.btnTitheList.Size = new System.Drawing.Size(190, 27);
            this.btnTitheList.TabIndex = 7;
            this.btnTitheList.Text = "Membership Data From Report";
            // 
            // panel8
            // 
            this.panel8.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel8.Controls.Add(this.linkLabelPreMemberDateForm);
            this.panel8.Controls.Add(this.linkLabelPeriodicMinistryActivity);
            this.panel8.Controls.Add(this.linkLabelPeriodicMemberActivity);
            this.panel8.Controls.Add(this.linkLabelRefreshReport);
            this.panel8.Location = new System.Drawing.Point(3, 3);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(516, 355);
            this.panel8.TabIndex = 6;
            this.panel8.TabStop = true;
            // 
            // linkLabelPeriodicMinistryActivity
            // 
            this.linkLabelPeriodicMinistryActivity.AutoSize = true;
            this.linkLabelPeriodicMinistryActivity.Location = new System.Drawing.Point(19, 78);
            this.linkLabelPeriodicMinistryActivity.Name = "linkLabelPeriodicMinistryActivity";
            this.linkLabelPeriodicMinistryActivity.Size = new System.Drawing.Size(121, 15);
            this.linkLabelPeriodicMinistryActivity.TabIndex = 8;
            this.linkLabelPeriodicMinistryActivity.Text = "Member Excel Form";
            // 
            // linkLabelPeriodicMemberActivity
            // 
            this.linkLabelPeriodicMemberActivity.AutoSize = true;
            this.linkLabelPeriodicMemberActivity.Location = new System.Drawing.Point(19, 28);
            this.linkLabelPeriodicMemberActivity.Name = "linkLabelPeriodicMemberActivity";
            this.linkLabelPeriodicMemberActivity.Size = new System.Drawing.Size(116, 15);
            this.linkLabelPeriodicMemberActivity.TabIndex = 7;
            this.linkLabelPeriodicMemberActivity.Text = "Member Data Form";
            // 
            // linkLabelRefreshReport
            // 
            this.linkLabelRefreshReport.AutoSize = true;
            this.linkLabelRefreshReport.Location = new System.Drawing.Point(19, 7);
            this.linkLabelRefreshReport.Name = "linkLabelRefreshReport";
            this.linkLabelRefreshReport.Size = new System.Drawing.Size(92, 15);
            this.linkLabelRefreshReport.TabIndex = 6;
            this.linkLabelRefreshReport.Text = "Refresh Report";
            // 
            // linkLabelPreMemberDateForm
            // 
            this.linkLabelPreMemberDateForm.AutoSize = true;
            this.linkLabelPreMemberDateForm.Location = new System.Drawing.Point(19, 52);
            this.linkLabelPreMemberDateForm.Name = "linkLabelPreMemberDateForm";
            this.linkLabelPreMemberDateForm.Size = new System.Drawing.Size(141, 15);
            this.linkLabelPreMemberDateForm.TabIndex = 9;
            this.linkLabelPreMemberDateForm.Text = "Pre-Member Data Form";
            // 
            // UCMemberShipForm
            // 
            this.Controls.Add(this.panel1);
            this.Name = "UCMemberShipForm";
            this.Size = new System.Drawing.Size(1063, 501);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.Panel panel1;
        private Wisej.Web.Panel panel3;
        private Wisej.Web.Panel panel5;
        private Wisej.Web.Panel panel4;
        private Wisej.Web.Panel panel7;
        private Wisej.Web.Panel panel6;
        private Wisej.Web.Panel panel2;
        private Wisej.Web.Label label1;
        private Wisej.Web.Button btnReportPreview;
        private Wisej.Web.Button btnTitheList;
        private Wisej.Web.Panel panel8;
        private Wisej.Web.LinkLabel linkLabelPreMemberDateForm;
        private Wisej.Web.LinkLabel linkLabelPeriodicMinistryActivity;
        private Wisej.Web.LinkLabel linkLabelPeriodicMemberActivity;
        private Wisej.Web.LinkLabel linkLabelRefreshReport;
    }
}
