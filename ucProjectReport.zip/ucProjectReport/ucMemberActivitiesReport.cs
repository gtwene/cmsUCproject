﻿using System;
using Wisej.Web;

namespace UCProject
{
    public partial class ucMemberActivitiesReport : Wisej.Web.UserControl
    {
        public ucMemberActivitiesReport()
        {
            InitializeComponent();
        }
    }
}
