﻿using System;
using Wisej.Web;

namespace UCProject
{
    public partial class ucFinanceNoGLReceiptEnquiry : Wisej.Web.UserControl
    {
        public ucFinanceNoGLReceiptEnquiry()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
