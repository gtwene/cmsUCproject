﻿using System;
using Wisej.Web;

namespace UCProject
{
    public partial class ucFinanceNO_GL_Receipt : Wisej.Web.UserControl
    {
        public ucFinanceNO_GL_Receipt()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
