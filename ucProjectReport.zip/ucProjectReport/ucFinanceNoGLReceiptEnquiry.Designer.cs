﻿namespace UCProject
{
    partial class ucFinanceNoGLReceiptEnquiry
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new Wisej.Web.Panel();
            this.panel2 = new Wisej.Web.Panel();
            this.txtSearch = new Wisej.Web.TextBox();
            this.dtpTo = new Wisej.Web.DateTimePicker();
            this.dtpFrom = new Wisej.Web.DateTimePicker();
            this.label1 = new Wisej.Web.Label();
            this.label2 = new Wisej.Web.Label();
            this.rbTitheNumber = new Wisej.Web.RadioButton();
            this.rbMemberName = new Wisej.Web.RadioButton();
            this.btnArrow = new Wisej.Web.Button();
            this.btnSearch = new Wisej.Web.Button();
            this.panel3 = new Wisej.Web.Panel();
            this.btnTransDetails = new Wisej.Web.Button();
            this.btnActiveTrans = new Wisej.Web.Button();
            this.label3 = new Wisej.Web.Label();
            this.panel4 = new Wisej.Web.Panel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.btnTransDetails);
            this.panel1.Controls.Add(this.btnActiveTrans);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = Wisej.Web.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(958, 481);
            this.panel1.TabIndex = 0;
            this.panel1.TabStop = true;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel2.Controls.Add(this.btnArrow);
            this.panel2.Controls.Add(this.btnSearch);
            this.panel2.Controls.Add(this.rbTitheNumber);
            this.panel2.Controls.Add(this.rbMemberName);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.txtSearch);
            this.panel2.Controls.Add(this.dtpTo);
            this.panel2.Controls.Add(this.dtpFrom);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(3, 74);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(950, 85);
            this.panel2.TabIndex = 1;
            this.panel2.TabStop = true;
            // 
            // txtSearch
            // 
            this.txtSearch.LabelText = "";
            this.txtSearch.Location = new System.Drawing.Point(307, 49);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(233, 22);
            this.txtSearch.TabIndex = 6;
            // 
            // dtpTo
            // 
            this.dtpTo.Checked = false;
            this.dtpTo.LabelText = "";
            this.dtpTo.Location = new System.Drawing.Point(47, 58);
            this.dtpTo.Name = "dtpTo";
            this.dtpTo.Size = new System.Drawing.Size(200, 22);
            this.dtpTo.TabIndex = 3;
            this.dtpTo.Value = new System.DateTime(2020, 12, 15, 8, 30, 26, 212);
            // 
            // dtpFrom
            // 
            this.dtpFrom.Checked = false;
            this.dtpFrom.LabelText = "";
            this.dtpFrom.Location = new System.Drawing.Point(47, 17);
            this.dtpFrom.Name = "dtpFrom";
            this.dtpFrom.Size = new System.Drawing.Size(200, 22);
            this.dtpFrom.TabIndex = 2;
            this.dtpFrom.Value = new System.DateTime(2020, 12, 15, 8, 30, 26, 212);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(47, -1);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "From : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(47, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(26, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "To : ";
            // 
            // rbTitheNumber
            // 
            this.rbTitheNumber.Location = new System.Drawing.Point(430, 11);
            this.rbTitheNumber.Name = "rbTitheNumber";
            this.rbTitheNumber.Size = new System.Drawing.Size(110, 22);
            this.rbTitheNumber.TabIndex = 9;
            this.rbTitheNumber.TabStop = true;
            this.rbTitheNumber.Text = "Tithe Number";
            // 
            // rbMemberName
            // 
            this.rbMemberName.Location = new System.Drawing.Point(307, 11);
            this.rbMemberName.Name = "rbMemberName";
            this.rbMemberName.Size = new System.Drawing.Size(117, 22);
            this.rbMemberName.TabIndex = 8;
            this.rbMemberName.TabStop = true;
            this.rbMemberName.Text = "Member Name";
            // 
            // btnArrow
            // 
            this.btnArrow.ImageSource = "icon-right";
            this.btnArrow.Location = new System.Drawing.Point(873, 11);
            this.btnArrow.Name = "btnArrow";
            this.btnArrow.Size = new System.Drawing.Size(59, 60);
            this.btnArrow.TabIndex = 11;
            // 
            // btnSearch
            // 
            this.btnSearch.ImageSource = "icon-search";
            this.btnSearch.Location = new System.Drawing.Point(626, 44);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(175, 27);
            this.btnSearch.TabIndex = 10;
            this.btnSearch.Text = "Search";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel3.Controls.Add(this.label3);
            this.panel3.Dock = Wisej.Web.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(956, 42);
            this.panel3.TabIndex = 2;
            this.panel3.TabStop = true;
            // 
            // btnTransDetails
            // 
            this.btnTransDetails.Location = new System.Drawing.Point(196, 45);
            this.btnTransDetails.Name = "btnTransDetails";
            this.btnTransDetails.Size = new System.Drawing.Size(206, 27);
            this.btnTransDetails.TabIndex = 4;
            this.btnTransDetails.Text = "Transaction Details";
            this.btnTransDetails.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnActiveTrans
            // 
            this.btnActiveTrans.Location = new System.Drawing.Point(4, 45);
            this.btnActiveTrans.Name = "btnActiveTrans";
            this.btnActiveTrans.Size = new System.Drawing.Size(190, 27);
            this.btnActiveTrans.TabIndex = 3;
            this.btnActiveTrans.Text = "Active Transactions";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(25, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(163, 15);
            this.label3.TabIndex = 12;
            this.label3.Text = "Online Receipts Processing";
            // 
            // panel4
            // 
            this.panel4.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel4.Location = new System.Drawing.Point(2, 161);
            this.panel4.Name = "panel4";
            this.panel4.ShowCloseButton = false;
            this.panel4.ShowHeader = true;
            this.panel4.Size = new System.Drawing.Size(950, 315);
            this.panel4.TabIndex = 5;
            this.panel4.TabStop = true;
            this.panel4.Text = "Receipt Trans. Enquiry";
            // 
            // ucFinanceNoGLReceiptEnquiry
            // 
            this.Controls.Add(this.panel1);
            this.Name = "ucFinanceNoGLReceiptEnquiry";
            this.Size = new System.Drawing.Size(958, 481);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.Panel panel1;
        private Wisej.Web.Panel panel2;
        private Wisej.Web.Label label2;
        private Wisej.Web.TextBox txtSearch;
        private Wisej.Web.DateTimePicker dtpTo;
        private Wisej.Web.DateTimePicker dtpFrom;
        private Wisej.Web.Label label1;
        private Wisej.Web.RadioButton rbTitheNumber;
        private Wisej.Web.RadioButton rbMemberName;
        private Wisej.Web.Panel panel3;
        private Wisej.Web.Button btnArrow;
        private Wisej.Web.Button btnSearch;
        private Wisej.Web.Button btnTransDetails;
        private Wisej.Web.Button btnActiveTrans;
        private Wisej.Web.Label label3;
        private Wisej.Web.Panel panel4;
    }
}
