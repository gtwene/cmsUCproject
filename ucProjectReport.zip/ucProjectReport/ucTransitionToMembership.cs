﻿using System;
using Wisej.Web;

namespace UCProject
{
    public partial class ucTransitionToMembership : Wisej.Web.UserControl
    {
        public ucTransitionToMembership()
        {
            InitializeComponent();
        }

        
        private void btnPreMemberToMember_Click(object sender, EventArgs e)
        {
          
        }
    }
}
