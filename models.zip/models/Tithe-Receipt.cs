﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UCProject.models
{
    public class Tithe_Receipt
    {
        public int txtTitheNo { get; set; }
        public int txtTitheRefNo { get; set; }
        public string txtMemberName { get; set; }
        public string txtMemberMinistry { get; set; }
        public string dtpActualDepositDate { get; set; }
        public float txtTransactionAmount { get; set; }
        public float cbIncome { get; set; }
        public string txtAccountNo { get; set; }
        public string cbService { get; set; }
        public string cbPaymentMonth { get; set; }
        public string cbPaymentYear { get; set; }
        public string txtTransAmount { get; set; }
    }
}