﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Web;
using System.Windows.Forms;

namespace UCProject.models
{
    public class No_GL_Receipt
    {
        public string txtMemberName { get; set; }
        public string txtMinistry { get; set; }
        public string cbIncomeType { get; set; }
        public int txtAccountNo { get; set; }
        public int txtTransAccount { get; set; }
        public string cbPaymentMonth { get; set; }
        public string cbPaymentYear { get; set; }
        public string dtpActualDepositDate { get; set; }
        public int txtTitheNo { get; set; }
        public int txtTitheRefNo { get; set; }
        public string cbService { get; set; }
    }
}