﻿using System;
using Wisej.Web;

namespace UCProject
{
    public partial class ucTitheReceipt : Wisej.Web.UserControl
    {
        public ucTitheReceipt()
        {
            InitializeComponent();
        }

        private void btnGetTithe_Click(object sender, EventArgs e)
        {

        }

        private void btnPostTrans_Click(object sender, EventArgs e)
        {
            try
            {
                if (Validate_Controls() == false)
                {
                    return;
                }

                DialogResult dialogResult = MessageBox.Show("Post ?", GlobalValueCore.ApplicationName, MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {

                    if (CreatePreMember())
                    {

                        GlobalValueCore.InformationMessage("Posted Successfully");
                        //CLEAR_TEXT();
                    }
                }
                else if (dialogResult == DialogResult.No)
                {
                    GlobalValueCore.InformationMessage("Cancelled by User");
                }
                //MessageBox.Show(""+branch.checkBranchName(txtBranchName.Text.ToString()));

            }
            catch (Exception ex)
            {
                GlobalValueCore.ExceptionMessage(ex.Message);
            }

        }

        private bool CreatePreMember()
        {
            throw new NotImplementedException();
        }

        private bool Validate_Controls()
        {

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtTitheNo.Text, "Please Enter Tithe Number !"))
            {
                txtTitheNo.Select();
                return false;
            }



            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtTitheRefNo.Text, "Please Enter Tithe Ref Number !"))
            {
                txtTitheRefNo.Select();
                return false;
            }


            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtMemberName.Text, "Please Enter Member Name !"))
            {
                txtMemberName.Select();
                return false;
            }


            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtMemberMinistry.Text, "Your Ministry."))
            {
                txtMemberMinistry.Select();
                return false;
            }
            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtTransactionAmount.Text, "Enter Amount Transfer.."))
            {
                txtTransactionAmount.Select();
                return false;
            }
            if (GlobalValueCore.CHECK_UI_IS_EMPTY(cbIncome.Text, "Cash Income"))
            {
                cbIncome.Select();
                return false;

            }

            if(GlobalValueCore.CHECK_UI_IS_EMPTY(cbService.Text, "THe Serice Your Joined! "))
            {
                cbService.Select();
                return false;
            }

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(cbPaymentMonth.Text, "Please Enter Month Paid"))
            {
                cbPaymentMonth.Select();
                return false;
            }

            if (GlobalValueCore.CHECK_UI_IS_EMPTY(cbPaymentYear.Text, "Please Enter Year Paid"))
            {
                cbPaymentYear.Select();
                return false;
            }


            if (GlobalValueCore.CHECK_UI_IS_EMPTY(txtTransAmount.Text, "Please Enter The Transacted Amount in Words"))
            {
                txtTransAmount.Select();
                return false;
            }

            //if (cbEmploymentStatus.Text == "Student")
            //{
            //    pResidentialinfo.Show();

            //}else
            //{
            //    pStudentResidentialInfo_PanelCollapsed()
            //}


            return true;
        }

        private void btnClearScreen_Click(object sender, EventArgs e)
        {
            CLEAR_SCREEN();
        }
        private void CLEAR_SCREEN()
        {
            txtTitheNo.Text = txtAccountNo.Text = txtAccountSmall.Text = txtGetTithe.Text = txtMemberMinistry.Text = txtMemberName.Text = txtTitheNo.Text = txtTitheRefNo.Text = txtTransAmount.Text = "";
            cbIncome.SelectedIndex = cbPaymentMonth.SelectedIndex = cbPaymentYear.SelectedIndex = cbService.SelectedIndex = -1;
        }
    }
 }

