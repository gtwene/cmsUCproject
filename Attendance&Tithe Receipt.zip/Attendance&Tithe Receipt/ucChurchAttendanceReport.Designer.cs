﻿namespace UCProject
{
    partial class ucChurchAttendanceReport
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new Wisej.Web.Panel();
            this.panel3 = new Wisej.Web.Panel();
            this.panel5 = new Wisej.Web.Panel();
            this.linkLabelAttendanceByPeriod = new Wisej.Web.LinkLabel();
            this.linkLabelAttendanceByDate = new Wisej.Web.LinkLabel();
            this.linkLabelRefreshReport = new Wisej.Web.LinkLabel();
            this.panel4 = new Wisej.Web.Panel();
            this.panel7 = new Wisej.Web.Panel();
            this.dtpSelectDate = new Wisej.Web.DateTimePicker();
            this.label1 = new Wisej.Web.Label();
            this.panel8 = new Wisej.Web.Panel();
            this.label4 = new Wisej.Web.Label();
            this.cbMinistry = new Wisej.Web.ComboBox();
            this.txtMinistry = new Wisej.Web.TextBox();
            this.panel6 = new Wisej.Web.Panel();
            this.dtpTo = new Wisej.Web.DateTimePicker();
            this.dtpFrom = new Wisej.Web.DateTimePicker();
            this.label3 = new Wisej.Web.Label();
            this.label2 = new Wisej.Web.Label();
            this.panel2 = new Wisej.Web.Panel();
            this.label5 = new Wisej.Web.Label();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1014, 488);
            this.panel1.TabIndex = 0;
            this.panel1.TabStop = true;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Location = new System.Drawing.Point(3, 87);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1006, 396);
            this.panel3.TabIndex = 2;
            this.panel3.TabStop = true;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel5.Controls.Add(this.linkLabelAttendanceByPeriod);
            this.panel5.Controls.Add(this.linkLabelAttendanceByDate);
            this.panel5.Controls.Add(this.linkLabelRefreshReport);
            this.panel5.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel5.HeaderForeColor = System.Drawing.Color.Black;
            this.panel5.Location = new System.Drawing.Point(514, 8);
            this.panel5.Name = "panel5";
            this.panel5.ShowCloseButton = false;
            this.panel5.ShowHeader = true;
            this.panel5.Size = new System.Drawing.Size(487, 383);
            this.panel5.TabIndex = 3;
            this.panel5.TabStop = true;
            this.panel5.Text = "Report Parameters";
            // 
            // linkLabelAttendanceByPeriod
            // 
            this.linkLabelAttendanceByPeriod.AutoSize = true;
            this.linkLabelAttendanceByPeriod.Location = new System.Drawing.Point(38, 61);
            this.linkLabelAttendanceByPeriod.Name = "linkLabelAttendanceByPeriod";
            this.linkLabelAttendanceByPeriod.Size = new System.Drawing.Size(129, 15);
            this.linkLabelAttendanceByPeriod.TabIndex = 2;
            this.linkLabelAttendanceByPeriod.Text = "Attendance By Period";
            // 
            // linkLabelAttendanceByDate
            // 
            this.linkLabelAttendanceByDate.AutoSize = true;
            this.linkLabelAttendanceByDate.Location = new System.Drawing.Point(38, 40);
            this.linkLabelAttendanceByDate.Name = "linkLabelAttendanceByDate";
            this.linkLabelAttendanceByDate.Size = new System.Drawing.Size(206, 15);
            this.linkLabelAttendanceByDate.TabIndex = 1;
            this.linkLabelAttendanceByDate.Text = "Attendance By Date ( Select Date )";
            // 
            // linkLabelRefreshReport
            // 
            this.linkLabelRefreshReport.AutoSize = true;
            this.linkLabelRefreshReport.Location = new System.Drawing.Point(38, 19);
            this.linkLabelRefreshReport.Name = "linkLabelRefreshReport";
            this.linkLabelRefreshReport.Size = new System.Drawing.Size(92, 15);
            this.linkLabelRefreshReport.TabIndex = 0;
            this.linkLabelRefreshReport.Text = "Refresh Report";
            // 
            // panel4
            // 
            this.panel4.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel4.Controls.Add(this.panel7);
            this.panel4.Controls.Add(this.panel8);
            this.panel4.Controls.Add(this.panel6);
            this.panel4.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel4.HeaderForeColor = System.Drawing.Color.Black;
            this.panel4.Location = new System.Drawing.Point(8, 8);
            this.panel4.Name = "panel4";
            this.panel4.ShowCloseButton = false;
            this.panel4.ShowHeader = true;
            this.panel4.Size = new System.Drawing.Size(500, 383);
            this.panel4.TabIndex = 3;
            this.panel4.TabStop = true;
            this.panel4.Text = "Report Parameters";
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.dtpSelectDate);
            this.panel7.Controls.Add(this.label1);
            this.panel7.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel7.HeaderForeColor = System.Drawing.Color.Black;
            this.panel7.Location = new System.Drawing.Point(16, 133);
            this.panel7.Name = "panel7";
            this.panel7.ShowCloseButton = false;
            this.panel7.ShowHeader = true;
            this.panel7.Size = new System.Drawing.Size(464, 100);
            this.panel7.TabIndex = 4;
            this.panel7.TabStop = true;
            this.panel7.Text = "By Date";
            // 
            // dtpSelectDate
            // 
            this.dtpSelectDate.Checked = false;
            this.dtpSelectDate.LabelText = "";
            this.dtpSelectDate.Location = new System.Drawing.Point(17, 36);
            this.dtpSelectDate.Name = "dtpSelectDate";
            this.dtpSelectDate.Size = new System.Drawing.Size(360, 22);
            this.dtpSelectDate.TabIndex = 6;
            this.dtpSelectDate.Value = new System.DateTime(2020, 11, 6, 11, 33, 42, 846);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 15);
            this.label1.TabIndex = 5;
            this.label1.Text = "Selected Date :";
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.label4);
            this.panel8.Controls.Add(this.cbMinistry);
            this.panel8.Controls.Add(this.txtMinistry);
            this.panel8.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel8.HeaderForeColor = System.Drawing.Color.Black;
            this.panel8.Location = new System.Drawing.Point(16, 235);
            this.panel8.Name = "panel8";
            this.panel8.ShowCloseButton = false;
            this.panel8.ShowHeader = true;
            this.panel8.Size = new System.Drawing.Size(464, 116);
            this.panel8.TabIndex = 4;
            this.panel8.TabStop = true;
            this.panel8.Text = "Ministry";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(17, 10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 15);
            this.label4.TabIndex = 7;
            this.label4.Text = "Ministry :";
            // 
            // cbMinistry
            // 
            this.cbMinistry.Location = new System.Drawing.Point(17, 31);
            this.cbMinistry.Name = "cbMinistry";
            this.cbMinistry.Size = new System.Drawing.Size(360, 22);
            this.cbMinistry.TabIndex = 1;
            // 
            // txtMinistry
            // 
            this.txtMinistry.Location = new System.Drawing.Point(17, 54);
            this.txtMinistry.Name = "txtMinistry";
            this.txtMinistry.Size = new System.Drawing.Size(360, 22);
            this.txtMinistry.TabIndex = 0;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.dtpTo);
            this.panel6.Controls.Add(this.dtpFrom);
            this.panel6.Controls.Add(this.label3);
            this.panel6.Controls.Add(this.label2);
            this.panel6.HeaderBackColor = System.Drawing.Color.LightBlue;
            this.panel6.HeaderForeColor = System.Drawing.Color.Black;
            this.panel6.Location = new System.Drawing.Point(16, 2);
            this.panel6.Name = "panel6";
            this.panel6.ShowCloseButton = false;
            this.panel6.ShowHeader = true;
            this.panel6.Size = new System.Drawing.Size(464, 132);
            this.panel6.TabIndex = 3;
            this.panel6.TabStop = true;
            this.panel6.Text = "Periodic Attendance Date";
            // 
            // dtpTo
            // 
            this.dtpTo.Checked = false;
            this.dtpTo.Location = new System.Drawing.Point(17, 76);
            this.dtpTo.Name = "dtpTo";
            this.dtpTo.Size = new System.Drawing.Size(360, 22);
            this.dtpTo.TabIndex = 4;
            this.dtpTo.Value = new System.DateTime(2020, 11, 6, 11, 33, 42, 846);
            // 
            // dtpFrom
            // 
            this.dtpFrom.Checked = false;
            this.dtpFrom.Location = new System.Drawing.Point(17, 24);
            this.dtpFrom.Name = "dtpFrom";
            this.dtpFrom.Size = new System.Drawing.Size(360, 22);
            this.dtpFrom.TabIndex = 3;
            this.dtpFrom.Value = new System.DateTime(2020, 11, 6, 11, 33, 42, 846);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 55);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(26, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "To :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "From : ";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightBlue;
            this.panel2.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel2.Controls.Add(this.label5);
            this.panel2.Dock = Wisej.Web.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1012, 46);
            this.panel2.TabIndex = 1;
            this.panel2.TabStop = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(11, 15);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(152, 15);
            this.label5.TabIndex = 5;
            this.label5.Text = "CHURCH ATTENDANCE";
            // 
            // ucChurchAttendanceReport
            // 
            this.Controls.Add(this.panel1);
            this.Name = "ucChurchAttendanceReport";
            this.Size = new System.Drawing.Size(1020, 494);
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.Panel panel1;
        private Wisej.Web.Panel panel3;
        private Wisej.Web.Panel panel5;
        private Wisej.Web.LinkLabel linkLabelAttendanceByPeriod;
        private Wisej.Web.LinkLabel linkLabelAttendanceByDate;
        private Wisej.Web.LinkLabel linkLabelRefreshReport;
        private Wisej.Web.Panel panel4;
        private Wisej.Web.Panel panel7;
        private Wisej.Web.DateTimePicker dtpSelectDate;
        private Wisej.Web.Label label1;
        private Wisej.Web.Panel panel8;
        private Wisej.Web.Label label4;
        private Wisej.Web.ComboBox cbMinistry;
        private Wisej.Web.TextBox txtMinistry;
        private Wisej.Web.Panel panel6;
        private Wisej.Web.DateTimePicker dtpTo;
        private Wisej.Web.DateTimePicker dtpFrom;
        private Wisej.Web.Label label3;
        private Wisej.Web.Label label2;
        private Wisej.Web.Panel panel2;
        private Wisej.Web.Label label5;
    }
}
