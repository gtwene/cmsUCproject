﻿namespace UCProject
{
    partial class ucTitheReceipt
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Wisej Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new Wisej.Web.Panel();
            this.panel2 = new Wisej.Web.Panel();
            this.txtGetTithe = new Wisej.Web.TextBox();
            this.panel3 = new Wisej.Web.Panel();
            this.rbMemberName = new Wisej.Web.RadioButton();
            this.rbTitheNumber = new Wisej.Web.RadioButton();
            this.btnGetTithe = new Wisej.Web.Button();
            this.panel4 = new Wisej.Web.Panel();
            this.panel5 = new Wisej.Web.Panel();
            this.panel6 = new Wisej.Web.Panel();
            this.label1 = new Wisej.Web.Label();
            this.txtTitheNo = new Wisej.Web.TextBox();
            this.label2 = new Wisej.Web.Label();
            this.txtTitheRefNo = new Wisej.Web.TextBox();
            this.label3 = new Wisej.Web.Label();
            this.txtMemberName = new Wisej.Web.TextBox();
            this.label4 = new Wisej.Web.Label();
            this.txtMemberMinistry = new Wisej.Web.TextBox();
            this.panel7 = new Wisej.Web.Panel();
            this.rdBankTransfer = new Wisej.Web.RadioButton();
            this.rdCash = new Wisej.Web.RadioButton();
            this.rdCheque = new Wisej.Web.RadioButton();
            this.panel8 = new Wisej.Web.Panel();
            this.txtTransactionAmount = new Wisej.Web.TextBox();
            this.label8 = new Wisej.Web.Label();
            this.label7 = new Wisej.Web.Label();
            this.dtpActualDepositDate = new Wisej.Web.DateTimePicker();
            this.label5 = new Wisej.Web.Label();
            this.cbIncome = new Wisej.Web.ComboBox();
            this.txtAccountNo = new Wisej.Web.TextBox();
            this.label6 = new Wisej.Web.Label();
            this.txtAccountSmall = new Wisej.Web.TextBox();
            this.label9 = new Wisej.Web.Label();
            this.cbService = new Wisej.Web.ComboBox();
            this.txtTransAmount = new Wisej.Web.TextBox();
            this.label10 = new Wisej.Web.Label();
            this.label11 = new Wisej.Web.Label();
            this.cbPaymentMonth = new Wisej.Web.ComboBox();
            this.label12 = new Wisej.Web.Label();
            this.cbPaymentYear = new Wisej.Web.ComboBox();
            this.toolBar1 = new Wisej.Web.ToolBar();
            this.btnPostTrans = new Wisej.Web.ToolBarButton();
            this.btnCancelTrans = new Wisej.Web.ToolBarButton();
            this.btnClearScreen = new Wisej.Web.ToolBarButton();
            this.label13 = new Wisej.Web.Label();
            this.btnReceipptTrans = new Wisej.Web.Button();
            this.button2 = new Wisej.Web.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = Wisej.Web.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1066, 659);
            this.panel1.TabIndex = 0;
            this.panel1.TabStop = true;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel2.Controls.Add(this.label13);
            this.panel2.Dock = Wisej.Web.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1064, 33);
            this.panel2.TabIndex = 0;
            this.panel2.TabStop = true;
            // 
            // txtGetTithe
            // 
            this.txtGetTithe.LabelText = "";
            this.txtGetTithe.Location = new System.Drawing.Point(17, 31);
            this.txtGetTithe.Name = "txtGetTithe";
            this.txtGetTithe.Size = new System.Drawing.Size(273, 22);
            this.txtGetTithe.TabIndex = 3;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel3.Controls.Add(this.btnGetTithe);
            this.panel3.Controls.Add(this.rbTitheNumber);
            this.panel3.Controls.Add(this.rbMemberName);
            this.panel3.Controls.Add(this.txtGetTithe);
            this.panel3.Location = new System.Drawing.Point(3, 39);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(471, 98);
            this.panel3.TabIndex = 5;
            this.panel3.TabStop = true;
            // 
            // rbMemberName
            // 
            this.rbMemberName.Location = new System.Drawing.Point(17, 3);
            this.rbMemberName.Name = "rbMemberName";
            this.rbMemberName.Size = new System.Drawing.Size(117, 22);
            this.rbMemberName.TabIndex = 6;
            this.rbMemberName.TabStop = true;
            this.rbMemberName.Text = "Member Name";
            // 
            // rbTitheNumber
            // 
            this.rbTitheNumber.Location = new System.Drawing.Point(180, 3);
            this.rbTitheNumber.Name = "rbTitheNumber";
            this.rbTitheNumber.Size = new System.Drawing.Size(110, 22);
            this.rbTitheNumber.TabIndex = 7;
            this.rbTitheNumber.TabStop = true;
            this.rbTitheNumber.Text = "Tithe Number";
            // 
            // btnGetTithe
            // 
            this.btnGetTithe.Location = new System.Drawing.Point(334, 26);
            this.btnGetTithe.Name = "btnGetTithe";
            this.btnGetTithe.Size = new System.Drawing.Size(105, 27);
            this.btnGetTithe.TabIndex = 8;
            this.btnGetTithe.Text = "Get Tithe";
            this.btnGetTithe.Click += new System.EventHandler(this.btnGetTithe_Click);
            // 
            // panel4
            // 
            this.panel4.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel4.Location = new System.Drawing.Point(3, 143);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(471, 491);
            this.panel4.TabIndex = 9;
            this.panel4.TabStop = true;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel5.Controls.Add(this.btnReceipptTrans);
            this.panel5.Controls.Add(this.button2);
            this.panel5.Controls.Add(this.toolBar1);
            this.panel5.Controls.Add(this.panel8);
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Location = new System.Drawing.Point(480, 39);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(509, 595);
            this.panel5.TabIndex = 10;
            this.panel5.TabStop = true;
            // 
            // panel6
            // 
            this.panel6.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel6.Controls.Add(this.label4);
            this.panel6.Controls.Add(this.txtMemberMinistry);
            this.panel6.Controls.Add(this.label3);
            this.panel6.Controls.Add(this.txtMemberName);
            this.panel6.Controls.Add(this.label2);
            this.panel6.Controls.Add(this.txtTitheRefNo);
            this.panel6.Controls.Add(this.label1);
            this.panel6.Controls.Add(this.txtTitheNo);
            this.panel6.Location = new System.Drawing.Point(2, 22);
            this.panel6.Name = "panel6";
            this.panel6.ShowCloseButton = false;
            this.panel6.ShowHeader = true;
            this.panel6.Size = new System.Drawing.Size(502, 174);
            this.panel6.TabIndex = 11;
            this.panel6.TabStop = true;
            this.panel6.Text = "Member Information";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 15);
            this.label1.TabIndex = 10;
            this.label1.Text = "Tithe No.";
            // 
            // txtTitheNo
            // 
            this.txtTitheNo.LabelText = "";
            this.txtTitheNo.Location = new System.Drawing.Point(3, 21);
            this.txtTitheNo.Name = "txtTitheNo";
            this.txtTitheNo.Size = new System.Drawing.Size(198, 22);
            this.txtTitheNo.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(237, 1);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 15);
            this.label2.TabIndex = 12;
            this.label2.Text = "Tithe Ref No.";
            // 
            // txtTitheRefNo
            // 
            this.txtTitheRefNo.LabelText = "";
            this.txtTitheRefNo.Location = new System.Drawing.Point(237, 22);
            this.txtTitheRefNo.Name = "txtTitheRefNo";
            this.txtTitheRefNo.Size = new System.Drawing.Size(260, 22);
            this.txtTitheRefNo.TabIndex = 11;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 49);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 15);
            this.label3.TabIndex = 14;
            this.label3.Text = "Member Name";
            // 
            // txtMemberName
            // 
            this.txtMemberName.LabelText = "";
            this.txtMemberName.Location = new System.Drawing.Point(3, 70);
            this.txtMemberName.Name = "txtMemberName";
            this.txtMemberName.Size = new System.Drawing.Size(494, 22);
            this.txtMemberName.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 98);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 15);
            this.label4.TabIndex = 16;
            this.label4.Text = "Member Ministry";
            // 
            // txtMemberMinistry
            // 
            this.txtMemberMinistry.LabelText = "";
            this.txtMemberMinistry.Location = new System.Drawing.Point(3, 119);
            this.txtMemberMinistry.Name = "txtMemberMinistry";
            this.txtMemberMinistry.Size = new System.Drawing.Size(494, 22);
            this.txtMemberMinistry.TabIndex = 15;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.White;
            this.panel7.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel7.Controls.Add(this.rdBankTransfer);
            this.panel7.Controls.Add(this.rdCash);
            this.panel7.Controls.Add(this.rdCheque);
            this.panel7.ForeColor = System.Drawing.Color.FromArgb(7, 5, 58);
            this.panel7.Location = new System.Drawing.Point(5, 5);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(489, 44);
            this.panel7.TabIndex = 13;
            this.panel7.TabStop = true;
            // 
            // rdBankTransfer
            // 
            this.rdBankTransfer.Location = new System.Drawing.Point(310, 11);
            this.rdBankTransfer.Name = "rdBankTransfer";
            this.rdBankTransfer.Size = new System.Drawing.Size(104, 22);
            this.rdBankTransfer.TabIndex = 1;
            this.rdBankTransfer.TabStop = true;
            this.rdBankTransfer.Text = "MoMo Trans";
            // 
            // rdCash
            // 
            this.rdCash.Location = new System.Drawing.Point(13, 11);
            this.rdCash.Name = "rdCash";
            this.rdCash.Size = new System.Drawing.Size(99, 22);
            this.rdCash.TabIndex = 6;
            this.rdCash.TabStop = true;
            this.rdCash.Text = "Cash Trans";
            // 
            // rdCheque
            // 
            this.rdCheque.Location = new System.Drawing.Point(164, 11);
            this.rdCheque.Name = "rdCheque";
            this.rdCheque.Size = new System.Drawing.Size(114, 22);
            this.rdCheque.TabIndex = 0;
            this.rdCheque.TabStop = true;
            this.rdCheque.Text = "Cheque Trans";
            // 
            // panel8
            // 
            this.panel8.BorderStyle = Wisej.Web.BorderStyle.Solid;
            this.panel8.Controls.Add(this.label12);
            this.panel8.Controls.Add(this.cbPaymentYear);
            this.panel8.Controls.Add(this.label11);
            this.panel8.Controls.Add(this.cbPaymentMonth);
            this.panel8.Controls.Add(this.txtTransAmount);
            this.panel8.Controls.Add(this.label10);
            this.panel8.Controls.Add(this.label9);
            this.panel8.Controls.Add(this.cbService);
            this.panel8.Controls.Add(this.txtAccountSmall);
            this.panel8.Controls.Add(this.txtAccountNo);
            this.panel8.Controls.Add(this.label6);
            this.panel8.Controls.Add(this.label5);
            this.panel8.Controls.Add(this.cbIncome);
            this.panel8.Controls.Add(this.txtTransactionAmount);
            this.panel8.Controls.Add(this.panel7);
            this.panel8.Controls.Add(this.label8);
            this.panel8.Controls.Add(this.label7);
            this.panel8.Controls.Add(this.dtpActualDepositDate);
            this.panel8.Location = new System.Drawing.Point(3, 198);
            this.panel8.Name = "panel8";
            this.panel8.ShowCloseButton = false;
            this.panel8.ShowHeader = true;
            this.panel8.Size = new System.Drawing.Size(501, 342);
            this.panel8.TabIndex = 14;
            this.panel8.TabStop = true;
            this.panel8.Text = "Transaction Details";
            // 
            // txtTransactionAmount
            // 
            this.txtTransactionAmount.LabelText = "";
            this.txtTransactionAmount.Location = new System.Drawing.Point(231, 87);
            this.txtTransactionAmount.Name = "txtTransactionAmount";
            this.txtTransactionAmount.Size = new System.Drawing.Size(263, 22);
            this.txtTransactionAmount.TabIndex = 23;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(231, 68);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(120, 15);
            this.label8.TabIndex = 25;
            this.label8.Text = "Transaction Amount";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(5, 68);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(118, 15);
            this.label7.TabIndex = 24;
            this.label7.Text = "Actual Deposit Date";
            // 
            // dtpActualDepositDate
            // 
            this.dtpActualDepositDate.Checked = false;
            this.dtpActualDepositDate.LabelText = "";
            this.dtpActualDepositDate.Location = new System.Drawing.Point(4, 87);
            this.dtpActualDepositDate.Name = "dtpActualDepositDate";
            this.dtpActualDepositDate.Size = new System.Drawing.Size(206, 22);
            this.dtpActualDepositDate.TabIndex = 22;
            this.dtpActualDepositDate.Value = new System.DateTime(2020, 12, 15, 10, 40, 33, 952);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(5, 118);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 15);
            this.label5.TabIndex = 27;
            this.label5.Text = "Income Type";
            // 
            // cbIncome
            // 
            this.cbIncome.DropDownStyle = Wisej.Web.ComboBoxStyle.DropDownList;
            this.cbIncome.Items.AddRange(new object[] {
            "Present",
            "Absent ",
            "Undetermine"});
            this.cbIncome.LabelText = "";
            this.cbIncome.Location = new System.Drawing.Point(5, 136);
            this.cbIncome.Name = "cbIncome";
            this.cbIncome.Size = new System.Drawing.Size(205, 22);
            this.cbIncome.TabIndex = 26;
            // 
            // txtAccountNo
            // 
            this.txtAccountNo.LabelText = "";
            this.txtAccountNo.Location = new System.Drawing.Point(231, 136);
            this.txtAccountNo.Name = "txtAccountNo";
            this.txtAccountNo.Size = new System.Drawing.Size(214, 22);
            this.txtAccountNo.TabIndex = 28;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(231, 117);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 15);
            this.label6.TabIndex = 29;
            this.label6.Text = "Account No";
            // 
            // txtAccountSmall
            // 
            this.txtAccountSmall.LabelText = "";
            this.txtAccountSmall.Location = new System.Drawing.Point(451, 136);
            this.txtAccountSmall.Name = "txtAccountSmall";
            this.txtAccountSmall.Size = new System.Drawing.Size(43, 22);
            this.txtAccountSmall.TabIndex = 30;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(5, 168);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(47, 15);
            this.label9.TabIndex = 32;
            this.label9.Text = "Service";
            // 
            // cbService
            // 
            this.cbService.DropDownStyle = Wisej.Web.ComboBoxStyle.DropDownList;
            this.cbService.Items.AddRange(new object[] {
            "Present",
            "Absent ",
            "Undetermine"});
            this.cbService.LabelText = "";
            this.cbService.Location = new System.Drawing.Point(5, 186);
            this.cbService.Name = "cbService";
            this.cbService.Size = new System.Drawing.Size(205, 22);
            this.cbService.TabIndex = 31;
            // 
            // txtTransAmount
            // 
            this.txtTransAmount.LabelText = "";
            this.txtTransAmount.Location = new System.Drawing.Point(5, 233);
            this.txtTransAmount.Multiline = true;
            this.txtTransAmount.Name = "txtTransAmount";
            this.txtTransAmount.Size = new System.Drawing.Size(489, 46);
            this.txtTransAmount.TabIndex = 33;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(5, 214);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(120, 15);
            this.label10.TabIndex = 34;
            this.label10.Text = "Transaction Amount";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(231, 168);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(95, 15);
            this.label11.TabIndex = 36;
            this.label11.Text = "Payment Month";
            // 
            // cbPaymentMonth
            // 
            this.cbPaymentMonth.DropDownStyle = Wisej.Web.ComboBoxStyle.DropDownList;
            this.cbPaymentMonth.Items.AddRange(new object[] {
            "January",
            "February",
            "March",
            "April",
            "May ",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December"});
            this.cbPaymentMonth.LabelText = "";
            this.cbPaymentMonth.Location = new System.Drawing.Point(231, 186);
            this.cbPaymentMonth.Name = "cbPaymentMonth";
            this.cbPaymentMonth.Size = new System.Drawing.Size(135, 22);
            this.cbPaymentMonth.TabIndex = 35;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(378, 168);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(86, 15);
            this.label12.TabIndex = 38;
            this.label12.Text = "Payment Year";
            // 
            // cbPaymentYear
            // 
            this.cbPaymentYear.DropDownStyle = Wisej.Web.ComboBoxStyle.DropDownList;
            this.cbPaymentYear.Items.AddRange(new object[] {
            "2020",
            "2019",
            "2018",
            "2017"});
            this.cbPaymentYear.LabelText = "";
            this.cbPaymentYear.Location = new System.Drawing.Point(378, 186);
            this.cbPaymentYear.Name = "cbPaymentYear";
            this.cbPaymentYear.Size = new System.Drawing.Size(116, 22);
            this.cbPaymentYear.TabIndex = 37;
            // 
            // toolBar1
            // 
            this.toolBar1.AutoSize = false;
            this.toolBar1.Buttons.AddRange(new Wisej.Web.ToolBarButton[] {
            this.btnPostTrans,
            this.btnCancelTrans,
            this.btnClearScreen});
            this.toolBar1.Dock = Wisej.Web.DockStyle.Bottom;
            this.toolBar1.Location = new System.Drawing.Point(0, 546);
            this.toolBar1.Name = "toolBar1";
            this.toolBar1.Size = new System.Drawing.Size(507, 47);
            this.toolBar1.TabIndex = 15;
            this.toolBar1.TabStop = false;
            // 
            // btnPostTrans
            // 
            this.btnPostTrans.ImageSource = "ajax-loader";
            this.btnPostTrans.Name = "btnPostTrans";
            this.btnPostTrans.Text = "Post Transaction";
            this.btnPostTrans.Click += new System.EventHandler(this.btnPostTrans_Click);
            // 
            // btnCancelTrans
            // 
            this.btnCancelTrans.ImageSource = "tab-close";
            this.btnCancelTrans.Name = "btnCancelTrans";
            this.btnCancelTrans.Text = "Cancel Transaction";
            // 
            // btnClearScreen
            // 
            this.btnClearScreen.ImageSource = "window-close";
            this.btnClearScreen.Name = "btnClearScreen";
            this.btnClearScreen.Text = "Clear Screen";
            this.btnClearScreen.Click += new System.EventHandler(this.btnClearScreen_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(428, 9);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(99, 15);
            this.label13.TabIndex = 17;
            this.label13.Text = "Member Receipt";
            // 
            // btnReceipptTrans
            // 
            this.btnReceipptTrans.Location = new System.Drawing.Point(3, 0);
            this.btnReceipptTrans.Name = "btnReceipptTrans";
            this.btnReceipptTrans.Size = new System.Drawing.Size(126, 21);
            this.btnReceipptTrans.TabIndex = 9;
            this.btnReceipptTrans.Text = "Receipt Transaction";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(132, 1);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(128, 20);
            this.button2.TabIndex = 10;
            this.button2.Text = "Scanned Cheque";
            // 
            // ucTitheReceipt
            // 
            this.Controls.Add(this.panel1);
            this.Name = "ucTitheReceipt";
            this.Size = new System.Drawing.Size(1066, 659);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Wisej.Web.Panel panel1;
        private Wisej.Web.Panel panel3;
        private Wisej.Web.TextBox txtGetTithe;
        private Wisej.Web.Panel panel2;
        private Wisej.Web.RadioButton rbMemberName;
        private Wisej.Web.RadioButton rbTitheNumber;
        private Wisej.Web.Panel panel4;
        private Wisej.Web.Button btnGetTithe;
        private Wisej.Web.Panel panel5;
        private Wisej.Web.Panel panel6;
        private Wisej.Web.Label label4;
        private Wisej.Web.TextBox txtMemberMinistry;
        private Wisej.Web.Label label3;
        private Wisej.Web.TextBox txtMemberName;
        private Wisej.Web.Label label2;
        private Wisej.Web.TextBox txtTitheRefNo;
        private Wisej.Web.Label label1;
        private Wisej.Web.TextBox txtTitheNo;
        private Wisej.Web.Panel panel8;
        private Wisej.Web.Panel panel7;
        private Wisej.Web.RadioButton rdBankTransfer;
        private Wisej.Web.RadioButton rdCash;
        private Wisej.Web.RadioButton rdCheque;
        private Wisej.Web.TextBox txtTransactionAmount;
        private Wisej.Web.Label label8;
        private Wisej.Web.Label label7;
        private Wisej.Web.DateTimePicker dtpActualDepositDate;
        private Wisej.Web.Label label12;
        private Wisej.Web.ComboBox cbPaymentYear;
        private Wisej.Web.Label label11;
        private Wisej.Web.ComboBox cbPaymentMonth;
        private Wisej.Web.TextBox txtTransAmount;
        private Wisej.Web.Label label10;
        private Wisej.Web.Label label9;
        private Wisej.Web.ComboBox cbService;
        private Wisej.Web.TextBox txtAccountSmall;
        private Wisej.Web.TextBox txtAccountNo;
        private Wisej.Web.Label label6;
        private Wisej.Web.Label label5;
        private Wisej.Web.ComboBox cbIncome;
        private Wisej.Web.Button btnReceipptTrans;
        private Wisej.Web.Button button2;
        private Wisej.Web.ToolBar toolBar1;
        private Wisej.Web.ToolBarButton btnPostTrans;
        private Wisej.Web.ToolBarButton btnCancelTrans;
        private Wisej.Web.ToolBarButton btnClearScreen;
        private Wisej.Web.Label label13;
    }
}
